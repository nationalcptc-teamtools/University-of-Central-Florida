#!/usr/bin/env bash
# Bring up a fully configured Ghostwriter.
#
#   ./ghostwriter.sh          start the stack and apply seed config
#   ./ghostwriter.sh --seed   re-apply seed config to an already-running stack
#   ./ghostwriter.sh --test   run the smoke test (needs a default template uploaded)
#   ./ghostwriter.sh --findings        add/replace [TEST] findings on the report
#   ./ghostwriter.sh --clear-findings  remove the [TEST] findings
#   ./ghostwriter.sh --mcp-setup      build/configure MCP on an existing running stack
#   ./ghostwriter.sh --mcp            stdio MCP transport (for an AI client's command)
#   ./ghostwriter.sh --mcp-test       read-only MCP connectivity and engagement checks
#   ./ghostwriter.sh --mcp-rotate-token  replace the dedicated MCP API token
#   ./ghostwriter.sh --mcp-revoke-token  disable the dedicated MCP API token
#   ./ghostwriter.sh --backup back up the database and uploaded files into the
#                    directory you ran this from
#   ./ghostwriter.sh --restore DB_FILE MEDIA_FILE
#                    REPLACE this instance's data with a --backup
#   ./ghostwriter.sh --down   stop the stack (keeps data)
#
# Safe to re-run at any point: the seed is idempotent and the smoke test
# rolls back everything it creates.
set -euo pipefail
# Remember where the caller ran us from - --backup writes there - before
# switching to the repo so docker compose finds its files.
CALLER_DIR="$PWD"
cd "$(dirname "$0")"

ensure_env() {
    if [[ -f .env ]]; then
        return
    fi
    echo "==> first run: generating .env"
    python3 mkenv.py
    echo
    echo "    If you want a named admin account, set these in .env now:"
    echo "      DJANGO_SUPERUSER_USERNAME / _EMAIL / _PASSWORD"
    echo
}

ensure_certs() {
    ./mkcerts.sh
}

start() {
    echo "==> starting stack"
    # --wait blocks until the django healthcheck passes, which is what
    # guarantees migrations have finished. The seed depends on rows those
    # migrations create (Severity, DocType), so seeding earlier fails
    # in confusing ways.
    docker compose up -d --wait
}

seed() {
    echo "==> applying seed configuration"
    local out status=0
    out=$(docker compose exec -T django python /app/manage.py shell < seed/seed.py 2>&1) || status=$?
    grep -v '^NEW_CREDENTIAL' <<<"$out" || true

    # New accounts come back as NEW_CREDENTIAL<TAB>user<TAB>password lines.
    # Keep them out of the terminal scrollback and in an owner-only file.
    if grep -q '^NEW_CREDENTIAL' <<<"$out"; then
        [[ -f credentials.txt ]] || printf 'username\tpassword\n' > credentials.txt
        grep '^NEW_CREDENTIAL' <<<"$out" | cut -f2,3 >> credentials.txt
        chmod 600 credentials.txt
        echo
        echo "    $(grep -c '^NEW_CREDENTIAL' <<<"$out") new account password(s) written to credentials.txt"
        echo "    Hand them out, then delete the file."
    fi
    return "$status"
}

smoke() {
    echo "==> smoke test"
    docker compose exec -T django python /app/manage.py shell < test/smoke.py
}

findings() {
    echo "==> generating test findings"
    docker compose exec -T django python /app/manage.py shell < test/gen_findings.py
}

clear_findings() {
    echo "==> clearing test findings"
    docker compose exec -T -e TEST_FINDINGS_CLEAR_ONLY=1 django \
        python /app/manage.py shell < test/gen_findings.py
}

mcp_setup() {
    echo "==> building pinned Ghostwriter MCP"
    docker compose build mcp
    python3 mcp/configure.py
}

mcp_run() {
    if [[ ! -s .mcp/token ]]; then
        echo "MCP is not configured; run ./ghostwriter.sh --mcp-setup first." >&2
        exit 1
    fi
    # Match host ownership of the 0700 directory / 0600 token. No TTY: stdout
    # belongs entirely to MCP JSON-RPC, including when started over ssh -T.
    exec docker compose run --rm --no-deps -T \
        --user "$(id -u):$(id -g)" mcp "$@"
}

mcp_test() {
    echo "==> read-only MCP smoke test"
    # A subshell lets mcp_run exec the transport without exiting setup early.
    (mcp_run /opt/cptc/deployment_smoke.py)
}

backup() {
    if [[ $(docker compose ps -q --status running postgres django | wc -l) -ne 2 ]]; then
        echo "backup: stack is not running - start it with ./ghostwriter.sh" >&2
        exit 1
    fi
    local stamp db_file media_file
    stamp=$(date +%Y_%m_%dT%H_%M_%S)
    media_file="$CALLER_DIR/media_$stamp.tar.gz"

    echo "==> backing up database"
    # Ghostwriter's own script: pg_dump | gzip into /backups inside the
    # postgres container, which is also where its `restore` script looks.
    docker compose exec -T postgres backup
    db_file=$(docker compose exec -T postgres sh -c 'ls -1t /backups | head -n1' | tr -d '\r')
    docker compose cp "postgres:/backups/$db_file" "$CALLER_DIR/$db_file"

    # Evidence, templates and logos are files on disk, not database rows.
    echo "==> backing up uploaded files"
    docker compose exec -T django tar czf - -C /app/ghostwriter/media . > "$media_file"

    # Both contain password hashes and engagement data.
    chmod 600 "$CALLER_DIR/$db_file" "$media_file"
    echo
    echo "Backup written to $CALLER_DIR:"
    echo "  $db_file"
    echo "  $(basename "$media_file")"
}

# Make a path given on the command line absolute, relative to where the caller
# ran us rather than the repo.
caller_path() {
    [[ "$1" == /* ]] && echo "$1" || echo "$CALLER_DIR/$1"
}

restore() {
    if [[ $# -ne 2 ]]; then
        echo "usage: $0 --restore backup_<stamp>.sql.gz media_<stamp>.tar.gz" >&2
        exit 2
    fi
    local db_path media_path db_file
    db_path=$(caller_path "$1")
    media_path=$(caller_path "$2")
    db_file=$(basename "$db_path")
    for f in "$db_path" "$media_path"; do
        [[ -f "$f" ]] || { echo "restore: $f not found" >&2; exit 1; }
    done

    echo "This REPLACES everything on this instance - reports, findings, evidence,"
    echo "users, the findings library and settings - with the contents of:"
    echo "  $db_path"
    echo "  $media_path"
    local answer
    read -r -p "Type 'yes' to continue: " answer
    [[ "$answer" == "yes" ]] || { echo "restore: aborted, nothing changed"; exit 1; }

    ensure_env
    ensure_certs

    # Only postgres stays up. Anything else connected to the database would
    # reconnect to it halfway through the drop-and-reload.
    echo "==> stopping everything except postgres"
    docker compose up -d --wait postgres
    docker compose stop django queue graphql_engine collab-server nginx

    echo "==> restoring database"
    # Ghostwriter's own script: drops the database, recreates it, loads the
    # dump. It only reads from /backups inside the container.
    docker compose cp "$db_path" "postgres:/backups/$db_file"
    docker compose exec -T postgres restore "$db_file"

    echo "==> restoring uploaded files"
    # Empty the media volume, then unpack into it. Runs in a throwaway django
    # container so the files end up owned by the same user as before.
    docker compose run --rm --no-deps -T --entrypoint sh django -c \
        'find /app/ghostwriter/media -mindepth 1 -delete && tar xzf - -C /app/ghostwriter/media' \
        < "$media_path"

    # No seed: the restored data already carries its own configuration, and
    # seeding would add accounts the source instance never had.
    start
    echo
    echo "Restored. Log in with accounts from the SOURCE instance."
    echo "Copy the source's .env over this one too if API tokens must keep working."
}

case "${1:-}" in
    --seed)
        seed
        ;;
    --test)
        smoke
        ;;
    --findings)
        findings
        ;;
    --clear-findings)
        clear_findings
        ;;
    --mcp-setup)
        mcp_setup
        mcp_test
        ;;
    --mcp)
        mcp_run
        ;;
    --mcp-test)
        mcp_test
        ;;
    --mcp-rotate-token)
        python3 mcp/configure.py --rotate
        mcp_test
        ;;
    --mcp-revoke-token)
        python3 mcp/configure.py --revoke
        ;;
    --backup)
        backup
        ;;
    --restore)
        shift
        restore "$@"
        ;;
    --down)
        docker compose down
        ;;
    "")
        ensure_env
        ensure_certs
        start
        seed
        mcp_setup
        mcp_test
        echo
        echo "Ghostwriter is up: https://localhost"
        ;;
    *)
        echo "usage: $0 [--seed|--test|--findings|--clear-findings|--mcp-setup|--mcp|--mcp-test|--mcp-rotate-token|--mcp-revoke-token|--backup|--restore DB MEDIA|--down]" >&2
        exit 2
        ;;
esac

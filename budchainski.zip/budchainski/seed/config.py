"""Everything this Ghostwriter instance should be configured with.

The privately maintained Final Full Template.docx is the report design source
of truth. Keep this public-safe configuration aligned with it; never commit
the DOCX. Edit values here, re-run ./ghostwriter.sh, done.
seed.py is generic machinery over this file and should rarely need changing.

Plain Python rather than YAML on purpose: the Ghostwriter image is not
guaranteed to ship PyYAML, and this way the config can carry comments.
"""

# ---------------------------------------------------------------------------
# Company identity
#
# Feeds {{ company.name }} and {{ company.email }} in the report templates -
# the cover page and the contact line. Leave this unset and every export is
# branded "SpecterOps".
# ---------------------------------------------------------------------------
COMPANY = {
    "company_name": "Butter Family Farms",
    "company_short_name": "BFF",
    "company_email": "",
    "company_address": "",
    "company_twitter": "",
}

# ---------------------------------------------------------------------------
# Severity colours
#
# Match the private template's severity table palette. Heading accents are
# controlled by the DOCX and may use darker shades. Bare hex, no leading '#'.
#
# Existing severities only have their colour touched - Severity.clean()
# reshuffles weights when they change, so seed.py writes nothing but `color`.
# A severity listed here that doesn't exist yet is created, sorted after all
# the existing ones.
# ---------------------------------------------------------------------------
SEVERITY_COLORS = {
    "Critical": "7030A0",      # purple
    "High": "C00000",          # dark red
    "Medium": "ED7D31",        # orange
    "Low": "70AD47",           # green
    "Informational": "2E75B6",  # blue
    # Not a Ghostwriter default - created by the seed. Placeholder severity for
    # pre-staged library findings; set the real rating when adding one to a
    # report.
    "UNKNOWN": "7A7A7A",        # grey
}

# ---------------------------------------------------------------------------
# Global report settings (ReportConfiguration singleton)
#
# Only keys listed here are written, so anything omitted keeps Ghostwriter's
# default.
# ---------------------------------------------------------------------------
REPORT_CONFIG = {
    # CharField with choices "3.1" / "4.0" - must be the string, not a number.
    "default_cvss_version": "4.0",      # templates say "CVSS v4.0 Vector"
    # Trailing space separates the label from Word's SEQ numbering field.
    "label_figure": "Figure ",
    "label_table": "Table",
    "title_case_captions": True,
}

# ---------------------------------------------------------------------------
# Extra fields
#
# (internal_name, display_name, type, description)
# type is one of: single_line_text, rich_text, integer, float, checkbox, json
#
# These are instance-wide: every Report grows the REPORT_FIELDS inputs and
# every Finding grows the FINDING_FIELDS inputs, whichever template is in use.
# A regionals report simply leaves previous_findings blank.
# ---------------------------------------------------------------------------
REPORT_FIELDS = [
    ("executive_summary", "Executive Summary", "rich_text",
     "Section 1.0 narrative."),
    ("business_impact", "Business & Safety Impact", "rich_text",
     "Section 1.1."),
    ("engagement_goals", "Engagement Goals", "rich_text",
     "Section 2.1. Use a bulleted list."),
    ("scope_narrative", "Scope Narrative", "rich_text",
     "Section 2.2 opening prose. The in-scope hosts themselves come from the "
     "project's scope lists."),
    ("scope_exclusions", "Scope Exclusions", "rich_text",
     "Section 2.2 out-of-scope statement."),
    ("scope_addendum", "Scope Addendum", "single_line_text",
     "Globals template only - one line in the executive summary panel."),
    ("network_map", "Network Map", "rich_text",
     "Figure 1. Insert the diagram as an image in the rich text editor."),
    ("security_strengths", "Security Strengths", "rich_text",
     "Section 2.3. Use a bulleted list."),
    ("areas_of_improvement", "Areas of Improvement", "rich_text",
     "Section 2.4. Use a bulleted list."),
    ("attack_chain", "Attack Chain Chart", "rich_text",
     "Figure 3. Insert the chart as an image."),
    ("additional_appendix", "Additional Appendix", "rich_text",
     "Optional trailing appendix. Leave empty to omit the whole section."),
    ("previous_findings", "Previous Findings", "json",
     'Globals template only - the retest table. A JSON list of objects with '
     'keys: id, title, severity, severity_color, status, status_color. '
     '`status` must be exactly "Remediated", "Not Remediated" or "Partially '
     'Remediated" for the summary counts to add up. Colours are bare hex.'),
]

FINDING_FIELDS = [
    ("impact_rating", "Impact Rating", "single_line_text",
     "Matrix Calculation row of the finding table, e.g. Critical."),
    ("likelihood_rating", "Likelihood Rating", "single_line_text",
     "Matrix Calculation row of the finding table, e.g. High."),
    ("mitre_attack", "MITRE ATT&CK Technique", "single_line_text",
     "e.g. T1083 - File and Directory Discovery"),
    ("mitre_mitigation", "MITRE ATT&CK Mitigation", "single_line_text",
     "e.g. M1027 - Password Policies"),
]

# Pre-filled starting value for the previous_findings JSON box, so the expected
# shape is visible rather than an empty field.
FIELD_DEFAULTS = {
    "previous_findings": """[
  {"id": "C1", "title": "Unauthenticated access to Bridge Command Center",
   "severity": "Critical", "severity_color": "7030A0",
   "status": "Remediated", "status_color": "00B050"},
  {"id": "H1", "title": "Local File Inclusion",
   "severity": "High", "severity_color": "FF0000",
   "status": "Not Remediated", "status_color": "FF0000"}
]""",
}

# ---------------------------------------------------------------------------
# Engagement: client, project and report
#
# Created on a fresh instance, in this order - a project needs its client and
# a report needs its project. Each is created only if missing and never
# updated afterwards, so edits made in the web UI during an engagement survive
# re-running the seed.
# ---------------------------------------------------------------------------
CLIENT = {
    "name": "Butter Family Farms",
    "short_name": "BFF",
    "codename": "LIGHTNING DRAGON",
    "logo": "butterfamilyfarms.png",    # a file in the repo's images/ directory
}

PROJECT = {
    "codename": "MAJOR KRAKEN",
    "project_type": "Penetration Test",  # must match a Ghostwriter project type
    "start_date": "2026-11-07",          # YYYY-MM-DD
    "end_date": "2026-11-07",
    "start_time": "09:00",               # 24-hour HH:MM
    "end_time": "17:00",
    "timezone": "America/New_York",      # IANA tz name
}

# Everyone in USERS (below) is assigned to the project with this role. Must be
# a Ghostwriter project role: Operator, Assessment Lead, Assessment Oversight.
# The admin account is not assigned.
PROJECT_ROLE = "Operator"

REPORT = {
    "title": "Southeast X Penetration Test",
    # Name of an existing DOCX template. Ghostwriter's stock one is below;
    # switch the report to the team template after uploading it by hand.
    "docx_template": "Default Word Template",
}

# ---------------------------------------------------------------------------
# Team accounts
#
# Each new account gets a random password, written to credentials.txt in the
# repo root (gitignored, owner-only) by ghostwriter.sh. Hand them out, then delete the
# file. Email is not configured, so password reset links are not an option.
#
# Add or remove people freely - re-running is safe and never touches an
# account that already exists, including its password.
#
# `role` is one of: user, manager, admin. Ghostwriter derives the Django
# is_staff / is_superuser flags from it, so role is the only thing to set.
# ---------------------------------------------------------------------------
USERS = [
    {"username": "caio", "role": "admin"},
    {"username": "ardian", "role": "admin"},
    {"username": "adam", "role": "admin"},
    {"username": "geo", "role": "admin"},
    {"username": "gabe", "role": "admin"},
    {"username": "jacob", "role": "admin"},
    {"username": "justin", "role": "admin"},
    {"username": "mike", "role": "admin"},
]

# Dedicated non-interactive MCP identity. The manager role supports the full
# client/project/report workflow without Django administrator privileges.
# This account can access all engagements, so keep its token private. Setup
# preserves usable tokens and renews them shortly before expiry.
MCP = {
    "username": "ghostwriter-mcp",
    "token_days": 30,
}

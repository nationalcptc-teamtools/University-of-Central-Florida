﻿"""Explicitly align the ATT&CK editor field with the private report template.

Run inside the Django container with:
    python /app/manage.py shell -c \
      "from runpy import run_path; print(run_path('/seed/migrate_mitre.py')['consolidate']())"

This converts only simple paragraph-wrapped technique strings to plain text,
changes the canonical field to single-line text, and removes the redundant
web-editor field specification. Legacy mitre_technique JSON values remain on
their records, so older report output and stored data are preserved. The
transaction aborts if it finds complex HTML rather than flattening it.
"""

import re
from html import unescape

from django.db import transaction

from ghostwriter.commandcenter.models import ExtraFieldSpec
from ghostwriter.reporting.models import Finding, ReportFindingLink

SIMPLE_PARAGRAPH = re.compile(r"<p>([^<]*)</p>", re.DOTALL)


def consolidate(dry_run=False):
    converted = 0
    with transaction.atomic():
        canonical = ExtraFieldSpec.objects.select_for_update().filter(
            target_model_id="reporting.Finding", internal_name="mitre_attack"
        ).first()
        if canonical is None or canonical.type not in {"rich_text", "single_line_text"}:
            raise RuntimeError("A text mitre_attack field must exist before consolidation")

        legacy = ExtraFieldSpec.objects.select_for_update().filter(
            target_model_id="reporting.Finding", internal_name="mitre_technique"
        ).first()

        for model in (Finding, ReportFindingLink):
            for row in model.objects.select_related(None).select_for_update(
                of=("self",)
            ).only("id", "extra_fields").iterator():
                fields = row.extra_fields
                if not isinstance(fields, dict):
                    continue
                value = fields.get("mitre_attack")
                if value is None or value == "":
                    continue
                if not isinstance(value, str):
                    raise RuntimeError(f"Non-text ATT&CK value in {model.__name__} {row.pk}")
                if not value.lstrip().startswith("<"):
                    continue
                match = SIMPLE_PARAGRAPH.fullmatch(value.strip())
                if match is None:
                    raise RuntimeError(f"Complex ATT&CK HTML in {model.__name__} {row.pk}")
                plain = unescape(match.group(1))
                if "\n" in plain or "\r" in plain:
                    raise RuntimeError(f"Multiline ATT&CK value in {model.__name__} {row.pk}")
                updated = dict(fields)
                updated["mitre_attack"] = plain
                model.objects.filter(pk=row.pk).update(extra_fields=updated)
                converted += 1

        type_changed = canonical.type != "single_line_text"
        if type_changed:
            ExtraFieldSpec.objects.filter(pk=canonical.pk).update(type="single_line_text")
        legacy_removed = legacy is not None
        if legacy_removed:
            legacy.delete()
        if dry_run:
            transaction.set_rollback(True)

    return {
        "dry_run": dry_run,
        "converted": converted,
        "type_changed": type_changed,
        "legacy_removed": legacy_removed,
    }

"""Set Ghostwriter's browser theme default before the web server starts.

Ghostwriter stores each user's explicit theme choice in localStorage. The
fallback embedded in its base templates is therefore the instance-wide
default for browsers that have not chosen a theme yet. Patch that fallback
to dark without overriding an existing browser preference.

This runs inside the django container from docker-compose.override.yml. It is
safe to run again when a container restarts. If an upstream release changes
the expected templates, fail loudly so an upgrade cannot silently revert the
instance to light mode.
"""

from __future__ import annotations

import os
from pathlib import Path


TEMPLATE_DIR = Path(
    os.environ.get(
        "GHOSTWRITER_TEMPLATE_DIR",
        "/app/ghostwriter/templates",
    )
)
TEMPLATE_NAMES = ("base_generic.html", "base_generic_empty.html")

FALLBACKS = (
    (
        "localStorage.getItem('ghostwriter-theme') || 'light'",
        "localStorage.getItem('ghostwriter-theme') || 'dark'",
    ),
    (
        "localStorage.getItem(THEME_STORAGE_KEY) || 'light'",
        "localStorage.getItem(THEME_STORAGE_KEY) || 'dark'",
    ),
)


def patch_template(path: Path) -> bool:
    """Patch one template and return whether its contents changed."""
    try:
        original = path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise SystemExit(f"default-theme: expected template is missing: {path}") from exc

    updated = original
    for light_fallback, dark_fallback in FALLBACKS:
        if light_fallback not in updated and dark_fallback not in updated:
            raise SystemExit(
                "default-theme: Ghostwriter's theme implementation changed; "
                f"could not find the expected fallback in {path}"
            )
        updated = updated.replace(light_fallback, dark_fallback)

    if updated == original:
        return False

    path.write_text(updated, encoding="utf-8")
    return True


def main() -> None:
    changed = [
        name
        for name in TEMPLATE_NAMES
        if patch_template(TEMPLATE_DIR / name)
    ]
    if changed:
        print(f"default-theme: dark enabled in {', '.join(changed)}")
    else:
        print("default-theme: dark already enabled")


if __name__ == "__main__":
    main()

"""Run by mcp/configure.py through manage.py shell, never directly.

Inputs are prepended to stdin by the host helper, keeping bearer credentials
out of process arguments and normal setup output. Provision first, save the
host file atomically, then finalize/revoke old managed tokens.
"""
import importlib.util
import json
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils import timezone
from ghostwriter.api.models import APIKey

MCP_ACTION = globals().get("MCP_ACTION")
MCP_EXISTING_TOKEN = globals().get("MCP_EXISTING_TOKEN", "")
MCP_ROTATE = globals().get("MCP_ROTATE", False)
if MCP_ACTION not in {"provision", "finalize", "revoke"}:
    raise ValueError("Run this script through mcp/configure.py")

TOKEN_NAME = "CPTC MCP (managed by up.sh)"
USER_NAME = "CPTC Ghostwriter MCP"
spec = importlib.util.spec_from_file_location("cptc_mcp_config", "/seed/config.py")
config = importlib.util.module_from_spec(spec)
spec.loader.exec_module(config)
settings = getattr(config, "MCP", {})
username = settings.get("username", "ghostwriter-mcp")
days = settings.get("token_days", 30)
if not isinstance(days, int) or isinstance(days, bool) or not 1 <= days <= 365:
    raise ValueError("MCP.token_days must be an integer between 1 and 365")
if not isinstance(username, str) or not username.strip():
    raise ValueError("MCP.username must be a non-empty username")

with transaction.atomic():
    User = get_user_model()
    user = User.objects.filter(username=username).first()
    if user is None:
        if MCP_ACTION != "provision":
            raise ValueError("MCP account does not exist; run --mcp-setup first")
        user = User(username=username, name=USER_NAME, role="manager")
        user.set_unusable_password()
        user.save()
    if (user.name != USER_NAME or user.role != "manager" or not user.is_active
            or user.is_staff or user.is_superuser or user.has_usable_password()):
        raise ValueError("MCP username is occupied by an interactive or changed account; "
                         "choose a dedicated username in seed/config.py")

    managed = APIKey.objects.filter(user=user, name=TOKEN_NAME, revoked=False)
    key = None
    if MCP_EXISTING_TOKEN:
        try:
            candidate = APIKey.objects.get_valid_from_token(MCP_EXISTING_TOKEN)
            if candidate.name == TOKEN_NAME and candidate.user_id != user.pk:
                raise ValueError("Saved token belongs to a different MCP.username. "
                                 "Restore the previous username and run "
                                 "--mcp-revoke-token before changing it.")
            if candidate.user_id == user.pk and candidate.name == TOKEN_NAME:
                key = candidate
        except APIKey.DoesNotExist:
            pass
    if MCP_ACTION == "revoke":
        count = managed.update(revoked=True)
        print(f"Revoked {count} managed MCP token(s).")
    else:
        if MCP_ACTION == "finalize":
            if key is None:
                raise ValueError("Saved MCP credential is not valid; rerun --mcp-setup")
            count = managed.exclude(pk=key.pk).update(revoked=True)
            print(f"MCP token saved; retired {count} previous managed token(s).")
        elif MCP_ACTION == "provision":
            renew_before = timezone.now() + timedelta(days=min(7, days / 4))
            renew = (MCP_ROTATE or key is None or key.expiry_date is None
                     or key.expiry_date <= renew_before)
            token = MCP_EXISTING_TOKEN
            if renew:
                key, token = APIKey.objects.create_token(
                    name=TOKEN_NAME, user=user,
                    expiry_date=timezone.now() + timedelta(days=days))
            print("MCP_CREDENTIAL\t" + json.dumps({
                "token": token, "username": user.username,
                "expires": key.expiry_date.isoformat(), "renewed": renew,
            }))
        else:
            raise ValueError("Unknown MCP credential action")

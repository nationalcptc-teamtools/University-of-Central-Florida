"""Apply seed/config.py to a running Ghostwriter instance.

Run via ghostwriter.sh, or by hand:

    docker compose exec -T django python /app/manage.py shell < seed/seed.py

Safe to re-run. Every object is matched on its natural key (internal_name,
severity name, username) rather than a primary key, so this
never collides with rows Ghostwriter's own migrations created and never
clobbers anything by ID the way `loaddata` would.

Must run AFTER migrations have finished - they create the Severity rows and
DocType rows this depends on. ghostwriter.sh gates on the django healthcheck for that.
"""
import importlib.util
import os
import sys

# Loaded by explicit path under a unique module name: Ghostwriter's own Django
# project package is also called `config`, so a plain `import config` picks up
# that one instead of ours.
CONFIG_PATH = "/seed/config.py"
if not os.path.isfile(CONFIG_PATH):
    sys.exit(f"seed: {CONFIG_PATH} not found - is the ./seed volume mounted? "
             "See docker-compose.override.yml")
_spec = importlib.util.spec_from_file_location("cptc_seed_config", CONFIG_PATH)
config = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(config)

from django.apps import apps
from django.contrib.auth import get_user_model

from ghostwriter.commandcenter.models import (
    CompanyInformation, ExtraFieldModel, ExtraFieldSpec, ReportConfiguration)
from ghostwriter.reporting.models import DocType, Severity

changes, notes = [], []


def log(changed, message):
    (changes if changed else notes).append(message)


# ---------------------------------------------------------------------------
# 0a. Load Ghostwriter's own initial fixtures on a bare database
#
# The images ship reporting/rolodex/shepherd/commandcenter `initial.json`
# fixtures - severities, doc types, finding types, project types - but /start
# does not load them; the official installer does. A database that has only
# been migrated is completely empty, and everything below depends on these
# rows existing.
#
# Ghostwriter overrides Django's loaddata: it takes an explicit path and skips
# records whose primary key already exists, so re-running never clobbers rows
# the team has customised.
# ---------------------------------------------------------------------------
import glob

from django.core.management import call_command

before = (DocType.objects.count(), Severity.objects.count())
for path in sorted(glob.glob("/app/ghostwriter/*/fixtures/initial.json")):
    call_command("loaddata", path, verbosity=0)
after = (DocType.objects.count(), Severity.objects.count())

if after != before:
    changes.append(f"Ghostwriter initial fixtures loaded "
                   f"({after[1]} severities, {after[0]} doc types)")
else:
    notes.append("Ghostwriter initial fixtures (already present)")

# ---------------------------------------------------------------------------
# 0b. Bootstrap the admin account
#
# /start runs migrations but does not create a superuser - the official
# installer does that as a separate step. Without this a fresh clone comes up
# with no way to log in.
#
# Note User.save() derives is_staff/is_superuser from `role`, so a plain
# create_superuser() produces a non-privileged account: role defaults to
# "user" and save() then clears both flags. The role is what matters.
# ---------------------------------------------------------------------------
User = get_user_model()
if not User.objects.filter(is_superuser=True).exists():
    su_name = os.environ.get("DJANGO_SUPERUSER_USERNAME", "").strip()
    su_pass = os.environ.get("DJANGO_SUPERUSER_PASSWORD", "").strip()
    su_mail = os.environ.get("DJANGO_SUPERUSER_EMAIL", "").strip()
    if not (su_name and su_pass):
        sys.exit("seed: no superuser exists and DJANGO_SUPERUSER_USERNAME / "
                 "DJANGO_SUPERUSER_PASSWORD are not set in .env")
    existing = User.objects.filter(username=su_name).first()
    if existing is not None:
        existing.role = "admin"
        existing.save()
        changes.append(f"promoted existing user {su_name!r} to admin")
    else:
        User.objects.create_superuser(username=su_name, email=su_mail,
                                      password=su_pass, role="admin")
        changes.append(f"superuser {su_name!r} created from DJANGO_SUPERUSER_* env")
else:
    notes.append("superuser (already exists)")

# ---------------------------------------------------------------------------
# 0c. Register which models accept extra fields
#
# No migration creates these rows, so on a genuinely fresh database the table
# is empty and creating an ExtraFieldSpec fails with ExtraFieldModel.DoesNotExist.
# The list and the collab flag mirror Ghostwriter's own generate_test_data
# command, so the Extra Field Configuration page ends up looking exactly as it
# would on a hand-set-up instance.
# ---------------------------------------------------------------------------
EXTRA_FIELD_MODELS = [
    "rolodex.Client", "rolodex.Project",
    "shepherd.Domain", "shepherd.StaticServer",
    "reporting.Finding", "reporting.Report", "reporting.ReportFindingLink",
    "reporting.Observation", "reporting.ReportObservationLink",
    "oplog.OplogEntry",
]
COLLAB_EDITABLE = {
    "reporting.Report", "reporting.ReportFindingLink",
    "reporting.ReportObservationLink", "oplog.OplogEntry",
}

for label in EXTRA_FIELD_MODELS:
    model = apps.get_model(label)
    _, created = ExtraFieldModel.objects.get_or_create(
        model_internal_name=label,
        defaults={
            "model_display_name": model._meta.verbose_name.title(),
            "is_collab_editable": label in COLLAB_EDITABLE,
        },
    )
    log(created, f"extra field model {label}")

# ---------------------------------------------------------------------------
# 1. Extra fields
# ---------------------------------------------------------------------------
for label, specs in (("reporting.Report", config.REPORT_FIELDS),
                     ("reporting.Finding", config.FINDING_FIELDS)):
    for internal, display, kind, description in specs:
        _, created = ExtraFieldSpec.objects.get_or_create(
            target_model_id=label,
            internal_name=internal,
            defaults={
                "display_name": display,
                "type": kind,
                "description": description,
                "user_default_value": config.FIELD_DEFAULTS.get(internal, ""),
            },
        )
        log(created, f"extra field {label}.{internal}")

# ---------------------------------------------------------------------------
# 2. Severity colours
#
# Ghostwriter's standard severities already exist (loaded from its fixtures);
# for those only the colour is written. Any other severity in the config, such
# as UNKNOWN, is created.
# Severity.clean() reshuffles weights when they change, so update_fields keeps
# this from disturbing the ordering.
# ---------------------------------------------------------------------------
from django.db.models import Max

for name, color in config.SEVERITY_COLORS.items():
    sev = Severity.objects.filter(severity=name).first()
    if sev is None:
        # New severities go after every existing one in sort order.
        last = Severity.objects.aggregate(top=Max("weight"))["top"] or 0
        Severity.objects.create(severity=name, weight=last + 1, color=color)
        log(True, f"severity {name} created (#{color}, sorted last)")
        continue
    if (sev.color or "").upper() != color.upper():
        sev.color = color
        sev.save(update_fields=["color"])
        log(True, f"severity {name} colour -> #{color}")
    else:
        log(False, f"severity {name} colour")

# ---------------------------------------------------------------------------
# 3. Company identity + global report settings (singletons)
# ---------------------------------------------------------------------------
company = CompanyInformation.get_solo()
touched = [f for f, v in config.COMPANY.items() if getattr(company, f, None) != v]
for field, value in config.COMPANY.items():
    setattr(company, field, value)
company.save()
log(bool(touched), f"company information ({', '.join(touched) if touched else 'unchanged'})")

report_config = ReportConfiguration.get_solo()
touched = []
for field, value in config.REPORT_CONFIG.items():
    if not hasattr(report_config, field):
        notes.append(f"report config: no such field {field!r} on this version - skipped")
        continue
    if getattr(report_config, field) != value:
        setattr(report_config, field, value)
        touched.append(field)
report_config.save()
log(bool(touched), f"report configuration ({', '.join(touched) if touched else 'unchanged'})")

# ---------------------------------------------------------------------------
# 4. Client, project and report
#
# Created in dependency order: project needs the client, report needs the
# project. Each is matched on its natural key, created only if missing, and
# never updated - people edit these in the UI mid-engagement, and re-running
# the seed must not revert their work.
#
# Everything that can fail is checked up front, before anything is written,
# and this step runs before the accounts step: team passwords are only handed
# to ghostwriter.sh at the very end, so aborting after accounts were created would
# leave those accounts with passwords nobody knows.
# ---------------------------------------------------------------------------
import datetime
import zoneinfo

from django.core.files import File

from ghostwriter.reporting.models import Report, ReportTemplate
from ghostwriter.rolodex.models import (
    Client, Project, ProjectAssignment, ProjectRole, ProjectType)

IMAGE_DIR = "/images"

client_cfg = dict(config.CLIENT)
logo_name = client_cfg.pop("logo", None)
logo_path = os.path.join(IMAGE_DIR, logo_name) if logo_name else None
project_cfg = config.PROJECT
report_cfg = config.REPORT

# -- pre-flight ------------------------------------------------------------
if logo_path and not os.path.isfile(logo_path):
    sys.exit(f"seed: client logo {logo_path} not found - is ./images mounted? "
             "See docker-compose.override.yml (run ./ghostwriter.sh, not --seed, after "
             "changing mounts so the container is recreated)")
project_type = ProjectType.objects.filter(
    project_type=project_cfg["project_type"]).first()
if project_type is None:
    sys.exit(f"seed: project type {project_cfg['project_type']!r} does not exist")
try:
    zoneinfo.ZoneInfo(project_cfg["timezone"])
except Exception:
    sys.exit(f"seed: {project_cfg['timezone']!r} is not a valid IANA timezone")
project_role = ProjectRole.objects.filter(project_role=config.PROJECT_ROLE).first()
if project_role is None:
    sys.exit(f"seed: project role {config.PROJECT_ROLE!r} does not exist")
report_template = ReportTemplate.objects.filter(
    name=report_cfg["docx_template"], doc_type__doc_type="docx").first()
if report_template is None:
    sys.exit(f"seed: DOCX template {report_cfg['docx_template']!r} does not exist")

# -- client ----------------------------------------------------------------
client = Client.objects.filter(name=client_cfg["name"]).first()
if client is None:
    client = Client(**client_cfg)
    if logo_path:
        with open(logo_path, "rb") as fh:
            client.logo.save(logo_name, File(fh), save=False)
    client.save()
    log(True, f"client {client.name!r}" + (" (with logo)" if logo_path else ""))
else:
    log(False, f"client {client.name!r}")

# -- project ---------------------------------------------------------------
project = Project.objects.filter(client=client,
                                 codename=project_cfg["codename"]).first()
if project is None:
    project = Project.objects.create(
        client=client,
        codename=project_cfg["codename"],
        project_type=project_type,
        start_date=datetime.date.fromisoformat(project_cfg["start_date"]),
        end_date=datetime.date.fromisoformat(project_cfg["end_date"]),
        start_time=datetime.time.fromisoformat(project_cfg["start_time"]),
        end_time=datetime.time.fromisoformat(project_cfg["end_time"]),
        timezone=project_cfg["timezone"],
    )
    log(True, f"project {project.codename!r}")
else:
    log(False, f"project {project.codename!r}")

# -- report ----------------------------------------------------------------
report = Report.objects.filter(project=project, title=report_cfg["title"]).first()
if report is None:
    report = Report.objects.create(
        title=report_cfg["title"],
        project=project,
        docx_template=report_template,
        created_by=User.objects.filter(is_superuser=True).order_by("id").first(),
    )
    log(True, f"report {report.title!r} (template {report_template.name!r})")
else:
    log(False, f"report {report.title!r}")

# ---------------------------------------------------------------------------
# 5. Team accounts
#
# Each NEW account gets a random password. Email is not configured on this
# instance, so self-service password reset cannot work - an account created
# without a password would be permanently locked out.
#
# /seed is mounted read-only, so the seed cannot write a credentials file
# itself. It prints one tab-separated NEW_CREDENTIAL line per account and
# ghostwriter.sh moves those lines into credentials.txt on the host (gitignored, 0600).
#
# Existing accounts are never touched, so re-running never rotates anyone's
# password out from under them.
# ---------------------------------------------------------------------------
import secrets
import string

_ALPHABET = string.ascii_letters + string.digits
new_credentials = []

for entry in config.USERS:
    username = entry["username"]
    if User.objects.filter(username=username).exists():
        log(False, f"user {username}")
        continue
    user = User(username=username, email=entry.get("email", ""))
    if "name" in entry:
        user.name = entry["name"]
    # is_staff/is_superuser are derived from role by User.save(), so role is
    # the only privilege setting worth writing. One of: user, manager, admin.
    user.role = entry.get("role", "user")
    password = "".join(secrets.choice(_ALPHABET) for _ in range(24))
    user.set_password(password)
    user.save()
    new_credentials.append((username, password))
    log(True, f"user {username} (role={user.role})")

# ---------------------------------------------------------------------------
# 6. Project assignments
#
# Everyone in USERS goes on the project with config.PROJECT_ROLE (the admin
# account is deliberately left off). Runs after the accounts step because it
# needs those users to exist. Only adds missing assignments - never removes or
# changes one, so roles adjusted in the UI survive a re-run.
# ---------------------------------------------------------------------------
for entry in config.USERS:
    member = User.objects.filter(username=entry["username"]).first()
    if member is None:
        notes.append(f"assignment: user {entry['username']!r} does not exist - skipped")
        continue
    if ProjectAssignment.objects.filter(project=project, operator=member).exists():
        log(False, f"assignment {member.username} -> {project.codename}")
        continue
    ProjectAssignment.objects.create(
        project=project, operator=member, role=project_role,
        start_date=project.start_date, end_date=project.end_date)
    log(True, f"assignment {member.username} -> {project.codename} "
              f"({project_role.project_role})")

# ---------------------------------------------------------------------------
print()
print(f"seed: {len(changes)} change(s)")
for line in changes:
    print("  +", line)
if notes:
    print(f"seed: {len(notes)} already current / note(s)")
    for line in notes:
        print("  =", line)

# Machine-readable, consumed and stripped by ghostwriter.sh. Printed last so a failure
# earlier in the seed never leaves a half-written credentials file behind.
for username, password in new_credentials:
    print(f"NEW_CREDENTIAL\t{username}\t{password}")

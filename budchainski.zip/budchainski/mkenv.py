#!/usr/bin/env python3
"""Create .env from .env.example, generating every <generated> secret.

Host-side helper, called by ghostwriter.sh on first run. Refuses to overwrite an
existing .env so re-running ghostwriter.sh never rotates live credentials.
"""
import pathlib
import re
import secrets
import string
import sys

ALPHABET = string.ascii_letters + string.digits
ROOT = pathlib.Path(__file__).parent
ENV, EXAMPLE = ROOT / ".env", ROOT / ".env.example"

if ENV.exists():
    sys.exit(".env already exists - leaving it alone")
if not EXAMPLE.exists():
    sys.exit(".env.example not found")

filled = []


def replace(match):
    filled.append(match.group(1))
    value = "".join(secrets.choice(ALPHABET) for _ in range(50))
    return f"{match.group(1)}={value}"


ENV.write_text(re.sub(r"^([A-Z_]+)=<generated>$", replace,
                      EXAMPLE.read_text(), flags=re.M))
ENV.chmod(0o600)
print(f"    .env created, {len(filled)} secret(s) generated")

# The admin password is needed to log in, so surface it once here rather than
# making someone go digging through .env.
admin = dict(
    line.split("=", 1) for line in ENV.read_text().splitlines()
    if line.startswith("DJANGO_SUPERUSER_") and "=" in line
)
if admin.get("DJANGO_SUPERUSER_PASSWORD"):
    print()
    print("    Log in with:")
    print(f"      username  {admin.get('DJANGO_SUPERUSER_USERNAME', 'admin')}")
    print(f"      password  {admin['DJANGO_SUPERUSER_PASSWORD']}")
    print("    (also in .env - change it after first login)")

"""Public configuration checks; optionally compare an external private DOCX.

python -m unittest discover -s test -p test_template_contract.py -v
Set GHOSTWRITER_TEST_TEMPLATE to a DOCX outside this repository for the private
comparison. Its contents are never copied into the repository or printed.
"""
import csv
import json
import os
import re
import runpy
import subprocess
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
CONFIG = runpy.run_path(str(ROOT / 'seed/config.py'))
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
WORD_SUFFIXES = {'.docx', '.docm', '.dotx', '.dotm'}


class ConfigurationContract(unittest.TestCase):
    def test_figure_label_preserves_separator_space(self):
        self.assertEqual(CONFIG['REPORT_CONFIG']['label_figure'], 'Figure ')

    def test_company_identity(self):
        company = CONFIG['COMPANY']
        self.assertEqual(company['company_name'], 'Butter Family Farms')
        self.assertEqual(company['company_short_name'], 'BFF')
        self.assertEqual(company['company_email'], '')

    def test_mitre_fields_are_unambiguous_plain_text(self):
        fields = CONFIG['FINDING_FIELDS']
        self.assertEqual(len(fields), len({f[0] for f in fields}))
        self.assertEqual(len(fields), len({f[1] for f in fields}))
        kinds = {f[0]: f[2] for f in fields}
        self.assertEqual(kinds['mitre_attack'], 'single_line_text')
        self.assertEqual(kinds['mitre_mitigation'], 'single_line_text')
        self.assertNotIn('mitre_technique', kinds)

    def test_csv_mitre_fields_match_seed(self):
        allowed = {field[0] for field in CONFIG['FINDING_FIELDS']}
        for path in (ROOT / 'csv_finding_templates').glob('*.csv'):
            with path.open(encoding='utf-8-sig', newline='') as stream:
                for row in csv.DictReader(stream):
                    fields = json.loads(row.get('extra_fields') or '{}')
                    mitre_fields = {key for key in fields if key.startswith('mitre_')}
                    self.assertLessEqual(mitre_fields, allowed, path.name)

    def test_unknown_remains_a_library_placeholder(self):
        self.assertIn('UNKNOWN', CONFIG['SEVERITY_COLORS'])
        self.assertEqual(len(CONFIG['SEVERITY_COLORS']), 6)

    def test_no_tracked_word_files_or_private_directory(self):
        paths = subprocess.check_output(
            ['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
        forbidden = [p for p in paths if Path(p).suffix.lower() in WORD_SUFFIXES
                     or 'private' in Path(p).parts]
        self.assertEqual(forbidden, [], 'Private Word files must not be tracked')

    def test_private_word_paths_are_ignored(self):
        for path in ['Final Full Template.docx', 'mcp/private.DOCX',
                     'test/report.DoCx', 'private/notes.txt']:
            result = subprocess.run(['git', 'check-ignore', '-q', '--', path], cwd=ROOT)
            self.assertEqual(result.returncode, 0, path)


@unittest.skipUnless(os.environ.get('GHOSTWRITER_TEST_TEMPLATE'),
                     'No external private template supplied')
class PrivateTemplateContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path = Path(os.environ['GHOSTWRITER_TEST_TEMPLATE']).resolve()
        if path.is_relative_to(ROOT):
            raise ValueError('Keep the private template outside the repository')
        cls.paragraphs = []
        with ZipFile(path) as archive:
            for name in archive.namelist():
                if name.startswith('word/') and name.endswith('.xml'):
                    root = ET.fromstring(archive.read(name))
                    for para in root.iter(W + 'p'):
                        cls.paragraphs.append(''.join(t.text or '' for t in para.iter(W + 't')))
        cls.text = '\n'.join(cls.paragraphs)

    def test_all_referenced_extra_fields_exist(self):
        report = {f[0] for f in CONFIG['REPORT_FIELDS']}
        finding = {f[0] for f in CONFIG['FINDING_FIELDS']}
        for prefix, name in re.findall(r'(finding\.)?extra_fields\.(\w+)', self.text):
            self.assertIn(name, finding if prefix else report)

    def test_severity_table_palette_matches(self):
        expression = next(p for p in self.paragraphs if 'set sev_color =' in p)
        expression = expression.translate(str.maketrans({'“':'"', '”':'"'}))
        colors = CONFIG['SEVERITY_COLORS']
        for severity in ['Critical', 'High', 'Medium', 'Low']:
            match = re.search(r'"([0-9A-Fa-f]{6})"\s+if\s+sev\s*==\s*"'
                              + severity + r'"', expression)
            self.assertIsNotNone(match, severity)
            self.assertEqual(match[1].upper(), colors[severity])
        fallback = re.search(r'else\s+"([0-9A-Fa-f]{6})"\s*%}', expression)
        self.assertIsNotNone(fallback)
        self.assertEqual(fallback[1].upper(), colors['Informational'])


if __name__ == '__main__':
    unittest.main()

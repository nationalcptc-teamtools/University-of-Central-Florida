"""Read-only private-template compatibility test inside Ghostwriter's container.

Set GHOSTWRITER_TEST_TEMPLATE to a privately staged DOCX path and optionally
GHOSTWRITER_TEST_CONFIG (default /seed/config.py). Run through manage.py shell.
Uses the seed's exact field schema without creating reports, changing the
database, saving output, or copying the private template into the repository.
"""
import copy
import io
import os
import runpy
from pathlib import Path
from zipfile import ZipFile

from django.core.files.storage import FileSystemStorage
from lxml import etree

from ghostwriter.commandcenter.models import ExtraFieldSpec
from ghostwriter.modules.linting_utils import LINTER_CONTEXT
from ghostwriter.modules.reportwriter.report.docx import ExportReportDocx
from ghostwriter.reporting.models import ReportTemplate

config = runpy.run_path(os.getenv('GHOSTWRITER_TEST_CONFIG', '/seed/config.py'))
template_path = Path(os.environ['GHOSTWRITER_TEST_TEMPLATE']).resolve(strict=True)
specs = {
    label: [ExtraFieldSpec(internal_name=f[0], display_name=f[1], type=f[2])
            for f in config[key]]
    for label, key in [('reporting.Report', 'REPORT_FIELDS'),
                       ('reporting.Finding', 'FINDING_FIELDS')]
}
reportable = ('Critical', 'High', 'Medium', 'Low', 'Informational')
colors = config['SEVERITY_COLORS']
ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
W = '{' + ns['w'] + '}'


class SeedExporter(ExportReportDocx):
    def extra_field_specs_for(self, model):
        return specs.get(model._meta.label, [])

    @classmethod
    def generate_lint_data(cls):
        data = copy.deepcopy(LINTER_CONTEXT)
        data['extra_fields'] = {s.internal_name: s.empty_value()
                                for s in specs['reporting.Report']}
        for finding in data['findings']:
            finding['extra_fields'] = {s.internal_name: s.empty_value()
                                       for s in specs['reporting.Finding']}
        return data


template = ReportTemplate(name='PRIVATE IN-MEMORY COMPATIBILITY TEST',
                          document=template_path.name)
template.document.storage = FileSystemStorage(location=str(template_path.parent))
warnings, errors = SeedExporter.lint(template)
assert not warnings and not errors, f'Lint failed: {warnings!r} {errors!r}'
print('PASS: exact-seed lint (0 warnings, 0 errors)')

data = SeedExporter.generate_lint_data()
data['evidence'] = []
data['observations'] = []
for spec in specs['reporting.Report']:
    if spec.type == 'rich_text':
        data['extra_fields'][spec.internal_name] = '<p>Section test.</p>'
base = copy.deepcopy(data['findings'][0])
data['findings'] = []
rich = ('<p>Test prose with <code>probe-inline-code</code>.</p>'
        '<ul><li>probe-bullet</li></ul><ol><li>probe-number</li></ol>'
        '<blockquote>probe-quote</blockquote><pre>probe-code-block</pre>')
for severity in reportable:
    for index in range(1, 3):
        number = len(data['findings']) + 1
        finding = copy.deepcopy(base)
        finding.update(id=number, title=f'PROBE {severity} {index}',
                       severity=severity, position=number,
                       severity_color=colors[severity],
                       severity_color_hex=colors[severity],
                       severity_color_rgb=[int(colors[severity][i:i+2], 16)
                                           for i in (0, 2, 4)],
                       cvss_score=5.0, evidence=[],
                       cvss_vector='CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:L/VI:L/VA:N/SC:N/SI:N/SA:N')
        finding['extra_fields'] = {'impact_rating':severity,
                                  'likelihood_rating':'High',
                                  'mitre_attack':f'PROBE-TECHNIQUE-{number}',
                                  'mitre_mitigation':f'PROBE-MITIGATION-{number}'}
        finding['affected_entities'] = f'<p>host-{number}.example.test</p>'
        for field in ('description', 'impact', 'mitigation', 'replication_steps', 'references'):
            finding[field] = rich
        data['findings'].append(finding)
data['severities'] = [{'severity':s, 'severity_color':colors[s], 'count':2, 'weight':i}
                      for i, s in enumerate(reportable)]
data['totals'].update(findings=10, findings_critical=2, findings_high=2,
                      findings_medium=2, findings_low=2, findings_info=2)
exporter = SeedExporter(data, is_raw=True, report_template=template, jinja_debug=True)
output = exporter.run().getvalue()
assert not exporter.jinja_undefined_variables, 'Undefined template variables'
with ZipFile(io.BytesIO(output)) as archive:
    root = etree.fromstring(archive.read('word/document.xml'))


def text(node):
    return ''.join(node.xpath('.//w:t/text()', namespaces=ns))


paragraphs = root.findall('.//w:p', ns)
body_text = text(root)
assert not root.xpath('//w:p[ancestor::w:p]', namespaces=ns), 'Nested Word paragraphs'
for number in range(1, 11):
    for marker in (f'PROBE-TECHNIQUE-{number}', f'PROBE-MITIGATION-{number}',
                   f'host-{number}.example.test'):
        assert marker in body_text, 'Finding field failed to render'
for probe in ('probe-inline-code', 'probe-bullet', 'probe-number', 'probe-quote', 'probe-code-block'):
    assert probe in body_text, 'Rich text failed to render'
applied = set(root.xpath('//w:pStyle/@w:val | //w:rStyle/@w:val', namespaces=ns))
assert {'BulletList', 'NumberList', 'CodeBlock', 'CodeInline', 'Blockquote'} <= applied
for severity in reportable:
    for index in range(1, 3):
        name = f'PROBE {severity} {index}'
        assert sum(name in text(p) for p in paragraphs) == 2, 'Missing summary or detail finding'
        heading = [p for p in paragraphs if name in text(p) and
                   p.xpath('./w:pPr/w:pStyle/@w:val', namespaces=ns) == ['Heading3']]
        assert len(heading) == 1, 'Missing individual finding heading'
summary_rows = []
for table in root.findall('.//w:tbl', ns):
    rows = table.findall('w:tr', ns)
    if rows and 'Vuln ID' in text(rows[0]):
        summary_rows.extend(rows[1:])
assert len(summary_rows) == 10, 'Expected ten summary rows'
for row in summary_rows:
    cell = row.findall('w:tc', ns)[-1]
    severity = text(cell).strip()
    fills = cell.xpath('./w:tcPr/w:shd/@w:fill', namespaces=ns)
    assert fills and fills[0].upper() == colors[severity], 'Summary colour mismatch'
detail_palettes = []
for table in root.findall('.//w:tbl', ns):
    if 'Matrix Calculation' in text(table) and 'CVSS Score' in text(table):
        detail_palettes.append(set(table.xpath('.//w:tcPr/w:shd/@w:fill', namespaces=ns)))
assert len(detail_palettes) == 10, 'Expected ten detail matrices'
for index, palette in enumerate(detail_palettes):
    assert colors[reportable[index // 2]] in {c.upper() for c in palette}, 'Detail colour mismatch'
print('PASS: 10 findings, 2 per reportable severity, 1 host each; MITRE, rich text, headings and colours')
with ZipFile(template_path) as archive:
    styles = etree.fromstring(archive.read('word/styles.xml'))
unnamed = sum(s.find(W+'name') is None for s in styles.findall(W+'style'))
if unnamed:
    print(f'NOTICE: private DOCX contains {unnamed} unnamed styles; Ghostwriter lint does not validate Word repair behaviour.')
print('PASS: no database records or exported files were written')

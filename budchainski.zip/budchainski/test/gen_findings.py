"""Fill the engagement report with test findings, for trying out report exports.

    ./ghostwriter.sh --findings         replace the test findings with a fresh set
    ./ghostwriter.sh --clear-findings   remove the test findings, touch nothing else

Adds one finding per row in FINDINGS below to the report named in
seed/config.py, so any uploaded template can be exported against a report that
has every severity, every finding type, and every rich-text construct the
templates render: paragraphs, bold and inline code, bulleted and numbered
lists, code blocks, block quotes and links. The prose is deliberately generic
placeholder text - the point is to exercise the template, not to read like a
real finding.

Every generated title starts with "[TEST] ". That prefix is how this script
finds its own findings again, and it shows in the web UI and in any export, so
test data cannot be mistaken for - or delivered as - real work. Re-running
replaces the previous test set rather than adding duplicates, and findings
without the prefix are never touched.
"""
import importlib.util
import os
import sys

from django.db import transaction

CONFIG_PATH = "/seed/config.py"
if not os.path.isfile(CONFIG_PATH):
    sys.exit(f"findings: {CONFIG_PATH} not found - is the ./seed volume mounted?")
# Loaded by path: Ghostwriter's own Django project package is also `config`.
_spec = importlib.util.spec_from_file_location("cptc_seed_config", CONFIG_PATH)
config = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(config)

from django.contrib.auth import get_user_model  # noqa: E402
from ghostwriter.reporting.models import (  # noqa: E402
    FindingType, Report, ReportFindingLink, Severity)
from ghostwriter.rolodex.models import Client, Project  # noqa: E402

PREFIX = "[TEST] "
CLEAR_ONLY = os.environ.get("TEST_FINDINGS_CLEAR_ONLY") == "1"

# ---------------------------------------------------------------------------
# Locate the engagement report from seed/config.py
# ---------------------------------------------------------------------------
client = Client.objects.filter(name=config.CLIENT["name"]).first()
project = client and Project.objects.filter(
    client=client, codename=config.PROJECT["codename"]).first()
report = project and Report.objects.filter(
    project=project, title=config.REPORT["title"]).first()
if not report:
    sys.exit(f"findings: report {config.REPORT['title']!r} not found - "
             "run ./ghostwriter.sh first so the seed creates it")

# ---------------------------------------------------------------------------
# Generic placeholder content, shared by every finding. Each block exercises a
# different rich-text construct the templates render.
# ---------------------------------------------------------------------------
def ul(*items):
    return "<ul>" + "".join(f"<li>{i}</li>" for i in items) + "</ul>"


def ol(*items):
    return "<ol>" + "".join(f"<li>{i}</li>" for i in items) + "</ol>"


DESCRIPTION = (
    "<p>Placeholder description for export testing. Lorem ipsum dolor sit "
    "amet, consectetur adipiscing elit. Checks body text in the template's "
    "<strong>Normal</strong> style and inline <code>monospace</code> spans.</p>")
IMPACT = (
    "<p>Placeholder impact narrative. Nulla facilisi.</p>"
    "<blockquote>A block quote, to check the Blockquote style renders.</blockquote>")
STEPS = (
    "<p>Placeholder reproduction steps:</p>"
    + ol("First step, as an ordered-list item.",
         "Second step, referring to the sample line below.",
         "Third step, to check numbered lists continue correctly.")
    + "<pre><code>example --flag placeholder-value  # sample, not a real command</code></pre>"
    + "<p>Supporting detail:</p>"
    + ul("Bullet item one.", "Bullet item two.", "Bullet item three."))
REMEDIATION = (
    "<p>Placeholder remediation guidance.</p>"
    + ul("Apply the relevant configuration change.",
         "Restrict access appropriately.",
         "Re-test after the change."))
REFERENCES = ul(
    '<a href="https://example.com/reference-one">https://example.com/reference-one</a>',
    '<a href="https://example.com/reference-two">https://example.com/reference-two</a>')

# ---------------------------------------------------------------------------
# The findings, as plain metadata. One row per (severity, type) pairing worth
# exercising, with a spread of CVSS scores. Names are Alpha, Bravo, ... so the
# set is obviously synthetic.
#   (severity, finding_type, phonetic, cvss_score, cvss_vector,
#    impact_rating, likelihood_rating, mitre_attack, mitre_mitigation, hosts)
# ---------------------------------------------------------------------------
V_HIGH = "AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H/SC:H/SI:H/SA:H"
V_MED = "AV:N/AC:L/AT:N/PR:L/UI:N/VC:L/VI:L/VA:N/SC:N/SI:N/SA:N"
V_LOW = "AV:L/AC:L/AT:N/PR:L/UI:N/VC:L/VI:N/VA:N/SC:N/SI:N/SA:N"
V_NONE = "AV:N/AC:L/AT:N/PR:N/UI:N/VC:N/VI:N/VA:N/SC:N/SI:N/SA:N"

FINDINGS = [
    ("Critical", "Web", "Alpha", "9.8", V_HIGH, "Critical", "Critical",
     "T1190 - Exploit Public-Facing Application", "M1051 - Update Software",
     "web01.example.local (10.20.1.10)"),
    ("Critical", "Network", "Bravo", "9.1", V_HIGH, "Critical", "High",
     "T1210 - Exploitation of Remote Services", "M1042 - Disable or Remove Feature",
     "10.20.1.0/24"),
    ("High", "Host", "Charlie", "8.4", V_HIGH, "High", "High",
     "T1068 - Exploitation for Privilege Escalation", "M1038 - Execution Prevention",
     "host05.example.local"),
    ("High", "Web", "Delta", "7.6", V_MED, "High", "Medium",
     "T1059 - Command and Scripting Interpreter", "M1038 - Execution Prevention",
     "portal.example.local"),
    ("High", "Wireless", "Echo", "7.1", V_MED, "High", "Medium",
     "T1557 - Adversary-in-the-Middle", "M1037 - Filter Network Traffic",
     "Corp-WiFi SSID"),
    ("Medium", "Network", "Foxtrot", "6.5", V_MED, "Medium", "Medium",
     "T1046 - Network Service Discovery", "M1030 - Network Segmentation",
     "10.20.2.0/24"),
    ("Medium", "Web", "Golf", "5.9", V_MED, "Medium", "Medium",
     "T1189 - Drive-by Compromise", "M1021 - Restrict Web-Based Content",
     "shop.example.local"),
    ("Medium", "Mobile", "Hotel", "5.3", V_MED, "Medium", "Low",
     "T1533 - Data from Local System", "M1057 - Data Loss Prevention",
     "ExampleApp v2.1 (Android)"),
    ("Low", "Host", "India", "3.9", V_LOW, "Low", "Low",
     "T1082 - System Information Discovery", "M1028 - Operating System Configuration",
     "host05.example.local"),
    ("Low", "Network", "Juliet", "3.1", V_LOW, "Low", "Low",
     "T1040 - Network Sniffing", "M1030 - Network Segmentation",
     "Multiple hosts"),
    ("Informational", "Web", "Kilo", "0.0", V_NONE, "Informational", "Low",
     "T1592 - Gather Victim Host Information", "N/A",
     "www.example.local"),
    ("Informational", "Network", "Lima", "0.0", V_NONE, "Informational", "Low",
     "T1590 - Gather Victim Network Information", "N/A",
     "10.20.0.0/16"),
]

# ---------------------------------------------------------------------------
# Apply
# ---------------------------------------------------------------------------
# Remove any prior test set. When only clearing, this is the whole job - and
# it must not sit inside the atomic block below, because a SystemExit raised
# inside transaction.atomic() is treated as an error and rolls the delete back.
removed = ReportFindingLink.objects.filter(
    report=report, title__startswith=PREFIX).delete()[0]

if CLEAR_ONLY:
    print(f"findings: removed {removed} test finding(s) from {report.title!r}")
    sys.exit(0)

with transaction.atomic():
    severities = {s.severity: s for s in Severity.objects.all()}
    types = {t.finding_type: t for t in FindingType.objects.all()}
    author = get_user_model().objects.filter(is_superuser=True).order_by("id").first()

    created = 0
    for position, row in enumerate(FINDINGS, start=1):
        (severity, ftype, phonetic, score, vector,
         impact_rating, likelihood, technique, mitigation, hosts) = row
        if severity not in severities:
            sys.exit(f"findings: severity {severity!r} does not exist")
        if ftype not in types:
            sys.exit(f"findings: finding type {ftype!r} does not exist")
        ReportFindingLink.objects.create(
            report=report,
            title=f"{PREFIX}{severity} {ftype} Finding {phonetic}",
            severity=severities[severity],
            finding_type=types[ftype],
            assigned_to=author,
            position=position,
            cvss_score=score,
            cvss_vector=vector,
            affected_entities=f"<p>{hosts}</p>",
            description=DESCRIPTION,
            impact=IMPACT,
            replication_steps=STEPS,
            mitigation=REMEDIATION,
            references=REFERENCES,
            extra_fields={
                "impact_rating": impact_rating,
                "likelihood_rating": likelihood,
                "mitre_attack": technique,
                "mitre_mitigation": mitigation,
            },
        )
        created += 1

from collections import Counter  # noqa: E402

counts = Counter(row[0] for row in FINDINGS)
order = ["Critical", "High", "Medium", "Low", "Informational"]
summary = ", ".join(f"{counts[s]} {s}" for s in order if counts.get(s))
verb = "replaced" if removed else "added"
print(f"findings: {verb} test set on {report.title!r} - {created} findings "
      f"({summary})")

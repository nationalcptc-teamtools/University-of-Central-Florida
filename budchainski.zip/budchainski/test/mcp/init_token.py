"""Run only in the disposable lab; write a temporary admin API token to a file."""
import json
from datetime import timedelta
from pathlib import Path
from django.contrib.auth import get_user_model
from django.utils import timezone
from ghostwriter.api.models import APIKey

_, token = APIKey.objects.create_token(
    name="ZZ MCP evaluation (safe to delete)",
    user=get_user_model().objects.get(username="admin"),
    expiry_date=timezone.now() + timedelta(hours=4),
)
path = Path("/tmp/mcp-eval-credentials.json")
path.write_text(json.dumps({"url": "http://127.0.0.1:18080/v1/graphql", "token": token}))
path.chmod(0o600)
print("Temporary lab credential written to /tmp/mcp-eval-credentials.json")

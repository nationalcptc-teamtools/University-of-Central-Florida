"""Read back synthetic benchmark rows through Django, independently of MCP."""
import json
from pathlib import Path
from ghostwriter.reporting.models import Finding, Report, ReportFindingLink
from ghostwriter.rolodex.models import Client, Project

out = {}
for owner in ["lsr00ter", "PaulDHaes", "ayoubbenmakker"]:
    prefix = "ZZ MCP " + owner
    out[owner] = {
        "clients": list(Client.objects.filter(name__startswith=prefix).values("id", "name")),
        "projects": list(Project.objects.filter(codename__startswith=prefix).values("id", "codename", "project_type_id", "timezone")),
        "reports": list(Report.objects.filter(title__startswith=prefix).values("id", "title", "extra_fields")),
        "library": list(Finding.objects.filter(title__startswith=prefix).values("id", "title", "severity__severity", "description", "impact", "mitigation", "replication_steps", "extra_fields", "cvss_score", "cvss_vector")),
        "reported": list(ReportFindingLink.objects.filter(report__title__startswith=prefix).values("id", "title", "report_id", "severity__severity", "description", "impact", "mitigation", "replication_steps", "affected_entities", "extra_fields", "cvss_score", "cvss_vector", "complete")),
    }
Path("/tmp/mcp-readback.json").write_text(json.dumps(out, indent=2, default=str))
print("Synthetic records captured for independent verification.")

# Ghostwriter MCP comparison for CPTC

Evaluated October 8, 2026 (October 9 UTC) against the repository's seeded
Ghostwriter v7.2.6 Docker stack. **Use lsr00ter/Ghostwriter-mcp as the initial
integration candidate.** It handled the tested finding workflow without source
changes. The other two required dependency adjustments and then failed important
parts of the CPTC workflow against the live schema.

This is a compatibility and reporting evaluation, not a security audit or a
production rollout. No candidate was connected to the team's live Ghostwriter.

## Why these checks match CPTC

`seed/config.py` defines twelve report extra fields, four finding extra fields,
six severity levels including UNKNOWN, and CVSS v4 defaults. The maintained
repository is configuration around official Ghostwriter images, rather than a
Ghostwriter source fork. Templates are uploaded separately. The existing smoke
test verifies rich text, Word styles and severity colours.

Consequently, the useful MCP must reuse the existing engagement, find reusable
library entries, attach independent report copies, preserve narrative and custom
fields, support re-rating UNKNOWN findings, and eventually fill report sections
and produce the document. Creating a generic finding alone is insufficient.

## Tested versions and startup

| Candidate | Commit | Pristine dependency install / startup | Adjustment used for live comparison |
|---|---|---|---|
| [lsr00ter](https://github.com/lsr00ter/Ghostwriter-mcp) | `44a5cbf` | Works; MCP 2.3.0 | None |
| [PaulDHaes](https://github.com/PaulDHaes/Ghostwriter-mcp) | `b7cb7d2` | Install works, startup fails: removed `mcp.server.fastmcp` import with MCP 2.x | Pin MCP to 1.30.0 (`mcp<2`) |
| [ayoubbenmakker](https://github.com/ayoubbenmakker/ghostwriter-ai-agent) | `188d976` | Install works, startup fails: undeclared `fastmcp` import | Add FastMCP 4.1.0 |

All three completed real stdio initialize/list-tools exchanges after those
dependency adjustments. No application source was patched. `uv pip check`
passed for all three final environments. Exact resolved dependencies and image
digests are included in `results/`. lsr00ter's 77 upstream unit tests passed.

## Live comparison

| CPTC capability | lsr00ter | PaulDHaes | ayoubbenmakker |
|---|---|---|---|
| Discover existing engagement | Pass: client, project, report, finding searches | Mixed: client/project searches fail on obsolete `note`; report/finding search and ID reads work | Mixed: clients/projects/library work; reports and report findings fail on `project_id` |
| Discover deployment-specific type/severity IDs | Pass | No tool | No tool |
| Create client/project/report | All pass | Client fails; project passes; report requires explicit date to avoid null `last_update` | Client passes; project/report fail on field names |
| Create findings at all six severities with CPTC extra fields | Pass | All six fail: custom keys are inserted as top-level fields; a minimal finding without custom fields works | All six fail on `report_id`; tool does not accept the custom fields |
| Attach an existing library finding | Pass, including all six newly created findings | Pass for a pre-created library fixture | No attachment tool |
| Edit only specified report-finding fields | Pass; other fields retained | Replication-step edit passes; affected entities retained | Partial update fails because omitted fields are sent as null; explicit complete-field update works |
| Re-rate report finding and store CVSS v4 vector | Pass | No corresponding update parameters | No corresponding update parameters |
| Update custom report sections | No tool | No tool | Summary tool exists but fails: `executive_summary` is not a top-level report field |
| Generate document through MCP | No tool | No tool | Fails: `generateReport` called with unsupported `reportId` argument |
| Error on nonexistent update target | Proper MCP error | Returns zero affected rows as success | Complete-field update returns `None` as success |
| Preserve library when editing report copy | Verified | Verified for tested step update | No equivalent library-attachment workflow |

The evaluation captured **75 tool calls**: 31 lsr00ter, 23 PaulDHaes, 21
ayoubbenmakker. These include deliberate error cases and different available
features; they are not comparable numerical scores. Tool-call results are in
`results/<candidate>.json`, and independent Django read-back is in
`results/readback.json`.

Both PaulDHaes and ayoubbenmakker return their GraphQL error messages in MCP
responses with `is_error=false`. A client checking only the protocol flag could
mistake a failed write for success. lsr00ter returns proper protocol errors and
rejects nonexistent update targets. Its delete tool also rejected a call without
the matching confirmation ID; the test record remained present. This is an
argument guard, not a human approval mechanism.

## Data and DOCX verification

Independent database reads verified that lsr00ter's six created library findings
and their report copies retained:

- `impact_rating`, `likelihood_rating`, `mitre_technique`, `mitre_mitigation`;
- rich-text description and reproduction content;
- impact and remediation text;
- their requested severity, including UNKNOWN.

Report-only edits left the library fixture unchanged. A follow-up stored a CVSS
v4 vector unchanged, and unrelated updates preserved existing affected entities
for both lsr00ter and PaulDHaes. The synthetic scores were not a CVSS-calculator
validation. Report extra-field sentinel values remained intact, but no candidate
successfully edited those sections through MCP.

Three historical templates were recovered from Git before deletion commit
`e63a09a`, solely into the external lab. Export used the actual MCP-populated
lsr00ter report, through Ghostwriter's Django exporter:

| Historical template | DOCX produced | Rich-text probes | MITRE technique / mitigation probes |
|---|---|---|---|
| `cptc-regionals.docx` | Yes | All present | Both present |
| `cptc-globals.docx` | Yes | All present | Both present |
| `CPTC-Template-GABE.docx` | Yes | All present | Both absent |

The repository's separate `test/smoke.py` passed with the recovered Regionals
template: all six severities, required Word styles, heading colours, and table
shading. Globals received content-probe checks, not that full style/colour test.
The GABE result is a historical-template limitation for these probes, not an MCP
failure. Exported files are retained outside Git under
`~/.cache/ghostwriter-mcp-eval/exports/`.

These results do not establish that the recovered files match the team's current
manually uploaded templates. No visual review was performed. Successful platform
export also does not mean that lsr00ter exposes an export MCP tool—it does not.

## Recommended integration work

Start with the pinned lsr00ter server as a separate component, preserving the
repo's configuration-only maintenance model. Add the following capabilities in
this order:

1. Read and update the twelve report extra fields, merging selected keys so
   editing `executive_summary` preserves `business_impact` and the other sections.
2. Read and update extra fields on an individual report finding. Currently the
   four CPTC fields can enter through library creation and attachment, but the
   report-finding update tool cannot change those values for one engagement.
3. Add evidence upload/association and report export with template selection.
   Verify the resulting DOCX through the existing smoke checks.
4. Package startup and configuration reproducibly, with the Ghostwriter URL,
   API token, and certificate trust supplied outside version control.
5. Consider operation-log tools as a separate follow-up, matching the optional
   oplog item in `ToDo.md`.

Before rollout, repeat export checks with the current uploaded template and
exercise the chosen client's complete reporting workflow. This run used admin
API tokens, matching all eight seeded CPTC users; it does not validate reduced
permissions, concurrent editors, evidence uploads, remote transport, or actual
model behaviour. The AI-agent project's additional LLM loop was not exercised.

"""Test the deployed MCP server over stdio; read-only unless --write is explicit.

Run inside the MCP image after its entrypoint has loaded the API credential.
Write acceptance tests create uniquely named fixtures and delete only the IDs
returned by their own create/attach calls. They never edit the seeded engagement.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import datetime as dt
import json
import os
import runpy
import sys
import tempfile
import uuid
from pathlib import Path

from mcp.client.stdio import stdio_client

from mcp import ClientSession, StdioServerParameters

SEVERITIES = ("Critical", "High", "Medium", "Low", "Informational", "UNKNOWN")
CVSS4 = "CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N"
RICH = "<p>ZZ MCP synthetic fixture.</p><ul><li>Sample</li></ul><pre><code>sample output</code></pre>"
REQUIRED_TOOLS = {
    "list_ghostwriter_lookups", "search_ghostwriter_clients",
    "search_ghostwriter_projects", "search_ghostwriter_reports",
    "search_ghostwriter_findings", "get_ghostwriter_client_by_id",
    "get_ghostwriter_project_by_id", "get_ghostwriter_report_by_id",
    "create_ghostwriter_client", "create_ghostwriter_project",
    "create_ghostwriter_report", "create_ghostwriter_finding",
    "attach_finding_to_report", "list_report_finding", "update_report_finding",
    "get_ghostwriter_report_extra_fields", "update_ghostwriter_report_extra_fields",
    "get_ghostwriter_report_finding_extra_fields",
    "list_ghostwriter_report_findings", "list_ghostwriter_finding_field_specs",
    "get_ghostwriter_report_finding_by_id",
    "list_ghostwriter_report_evidence", "get_ghostwriter_evidence_image",
    "view_ghostwriter_evidence_image",
    "update_ghostwriter_report_finding_extra_fields",
    "delete_ghostwriter_client", "delete_ghostwriter_project",
    "delete_ghostwriter_report", "delete_ghostwriter_finding",
    "delete_ghostwriter_report_finding",
}


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def response_error(value):
    """Catch GraphQL errors even if a server incorrectly reports MCP success."""
    if isinstance(value, dict):
        if value.get("errors") or value.get("error") or value.get("isError"):
            return True
        return any(response_error(child) for child in value.values())
    if isinstance(value, list):
        return any(response_error(child) for child in value)
    return False


def protocol_diagnostic(result):
    """Return a short, token-redacted error message, never arbitrary success data."""
    texts = [block.text for block in result.content if getattr(block, "type", None) == "text"]
    diagnostic = " ".join(texts).replace("\n", " ")
    token = os.getenv("GHOSTWRITER_API_TOKEN", "")
    if token:
        diagnostic = diagnostic.replace(token, "[REDACTED]")
    return diagnostic[:500]


def unpack(result):
    structured = getattr(result, "structured_content", getattr(result, "structuredContent", None))
    if structured is not None:
        if isinstance(structured, dict) and set(structured) == {"result"}:
            return structured["result"]
        return structured
    blocks = []
    for block in result.content:
        require(block.type == "text", "Expected a JSON text tool result")
        try:
            blocks.append(json.loads(block.text))
        except (TypeError, ValueError) as exc:
            raise AssertionError("Tool returned non-JSON success content") from exc
    return blocks[0] if len(blocks) == 1 else blocks


def rows(value):
    if isinstance(value, list):
        return value
    require(isinstance(value, dict), "Expected a record or records")
    return [value]


def one(value):
    records = rows(value)
    require(len(records) == 1, "Expected exactly one record")
    require(isinstance(records[0], dict), "Expected a record object")
    return records[0]


def row_id(value):
    identifier = one(value).get("id")
    require(isinstance(identifier, (int, str)) and int(identifier) > 0, "Missing record ID")
    return int(identifier)


def expected_names(args):
    config = {}
    path = Path(args.config)
    if path.is_file():
        config = runpy.run_path(str(path))
    return (
        args.client_name or config.get("CLIENT", {}).get("name", "Butter Family Farms"),
        args.project_codename or config.get("PROJECT", {}).get("codename", "MAJOR KRAKEN"),
        args.report_title or config.get("REPORT", {}).get("title", "Southeast X Penetration Test"),
    )


class Checks:
    def __init__(self, session):
        self.session = session
        self.calls = 0
        self.expected_errors = 0

    async def call(self, tool, *, expect_error=False, **arguments):
        result = await self.session.call_tool(tool, arguments)
        self.calls += 1
        failed = getattr(result, "is_error", getattr(result, "isError", False))
        if expect_error:
            require(failed, f"{tool}: expected an MCP protocol error")
            self.expected_errors += 1
            return None
        require(not failed, f"{tool}: MCP tool failed: {protocol_diagnostic(result) if failed else ''}")
        value = unpack(result)
        require(not response_error(value), f"{tool}: nested API error")
        return value


async def read_only(checks, args):
    lookups = one(await checks.call("list_ghostwriter_lookups"))
    severities = {row["name"]: int(row["id"]) for row in lookups["severities"]}
    require(set(SEVERITIES) <= severities.keys(), "Missing one of the six configured severities")
    require(lookups.get("projectTypes") and lookups.get("findingTypes"), "Lookup tables are empty")
    client_name, project_codename, report_title = expected_names(args)
    clients = rows(await checks.call("search_ghostwriter_clients", search_term=client_name))
    client = one([row for row in clients if row["name"] == client_name])
    client_id = row_id(client)
    require(row_id(await checks.call("get_ghostwriter_client_by_id", clientId=client_id)) == client_id,
            "Client lookup returned the wrong record")
    projects = rows(await checks.call("search_ghostwriter_projects", search_term=project_codename))
    project = one([row for row in projects if row["codename"] == project_codename
                   and int(row["clientId"]) == client_id])
    project_id = row_id(project)
    require(row_id(await checks.call("get_ghostwriter_project_by_id", projectId=project_id)) == project_id,
            "Project lookup returned the wrong record")
    reports = rows(await checks.call("search_ghostwriter_reports", search_term=report_title))
    report = one([row for row in reports if row["title"] == report_title
                  and int(row["projectId"]) == project_id])
    report_id = row_id(report)
    require(row_id(await checks.call("get_ghostwriter_report_by_id", reportId=report_id)) == report_id,
            "Report lookup returned the wrong record")
    extra = one(await checks.call("get_ghostwriter_report_extra_fields", reportId=report_id))
    require(row_id(extra) == report_id, "Report custom-field lookup returned the wrong record")
    require(isinstance(extra.get("extraFields"), dict), "Report custom fields are not an object")
    findings = rows(await checks.call("list_report_finding", reportId=report_id))
    detailed_findings = rows(await checks.call("list_ghostwriter_report_findings", reportId=report_id))
    require({row_id(f) for f in detailed_findings} == {row_id(f) for f in findings},
            "Report-specific finding list disagrees with the upstream list")
    field_specs = rows(await checks.call("list_ghostwriter_finding_field_specs"))
    technique_specs = [item for item in field_specs if item["displayName"] == "MITRE ATT&CK Technique"]
    require(len(technique_specs) == 1 and technique_specs[0]["internalName"] == "mitre_attack"
            and technique_specs[0]["type"] == "single_line_text",
            "Finding editor does not have exactly one canonical ATT&CK field")
    for finding in detailed_findings:
        require("severityId" in finding, "Report finding severity was omitted")
        require("position" in finding and "cvssScore" in finding and "cvssVector" in finding,
                "Report finding order or CVSS rating was omitted")
    if detailed_findings:
        detail = one(await checks.call("get_ghostwriter_report_finding_by_id",
                                       reportedFindingId=row_id(detailed_findings[0])))
        require(int(detail["reportId"]) == report_id, "Finding detail belongs to another report")
        require("description" in detail and "replication_steps" in detail,
                "Finding detail omitted its report-specific narrative")
    evidence = rows(await checks.call("list_ghostwriter_report_evidence", reportId=report_id))
    images = [item for item in evidence if Path(item["document"]).suffix.lower()
              in {".png", ".jpg", ".jpeg", ".gif", ".webp"}]
    if images:
        image = one(await checks.call("get_ghostwriter_evidence_image", reportId=report_id,
                                      evidenceId=row_id(images[0])))
        require(image["reportId"] == report_id and image["mimeType"].startswith("image/"),
                "Evidence image does not belong to this report")
        require(base64.b64decode(image["imageBase64"], validate=True),
                "Evidence image is empty or invalid base64")
        native = await checks.session.call_tool("view_ghostwriter_evidence_image", {
            "reportId": report_id, "evidenceId": row_id(images[0]),
        })
        checks.calls += 1
        require(not native.is_error, "Native evidence image tool failed")
        blocks = [block for block in native.content if block.type == "image"]
        require(len(blocks) == 1 and base64.b64decode(blocks[0].data, validate=True),
                "Native evidence image content is missing or invalid")
    for finding in findings:
        extra = one(await checks.call("get_ghostwriter_report_finding_extra_fields",
                                      reportedFindingId=row_id(finding)))
        require(row_id(extra) == row_id(finding), "Finding custom-field lookup returned the wrong record")
        require(isinstance(extra.get("extraFields"), dict), "Finding custom fields are not an object")
    print(f"PASS read-only: six severities, seeded engagement, report fields, {len(findings)} finding(s)")
    return lookups, severities


async def persisted(table, identifier):
    """Independent readback of stored fields, rather than trusting mutation echoes."""
    import ghostwriter_api as gw

    require(table in {"finding", "reportedFinding", "report"}, "Unexpected readback table")
    fields = "id title extraFields"
    if table != "report":
        fields += " description impact mitigation replication_steps severityId cvssScore cvssVector"
    if table == "reportedFinding":
        fields += " affectedEntities"
    payload = await gw._post(
        f"query MCPDeploymentReadback($id: bigint!) {{ {table}(where: {{id: {{_eq: $id}}}}) {{ {fields} }} }}",
        {"id": identifier},
    )
    require(not response_error(payload), "Stored-record readback returned API errors")
    return one(payload["data"][table])


async def acceptance(checks, lookups, severities):
    suffix = uuid.uuid4().hex[:10]
    prefix = f"ZZ MCP deployment {suffix}"
    name = prefix + " (safe to delete)"
    # IDs enter these lists only after this run has created/attached the record.
    owned = {"reportedFinding": [], "report": [], "project": [], "client": [], "finding": []}
    delete_tools = {
        "reportedFinding": ("delete_ghostwriter_report_finding", "reportedFindingId"),
        "report": ("delete_ghostwriter_report", "reportId"),
        "project": ("delete_ghostwriter_project", "projectId"),
        "client": ("delete_ghostwriter_client", "clientId"),
        "finding": ("delete_ghostwriter_finding", "findingId"),
    }
    cleanup_errors = []
    try:
        client_id = row_id(await checks.call("create_ghostwriter_client", name=name,
                                            shortName="ZZTEST", codename=prefix))
        owned["client"].append(client_id)
        project_type = next((row for row in lookups["projectTypes"]
                             if row["name"] == "Penetration Test"), lookups["projectTypes"][0])
        today = dt.date.today().isoformat()
        project_id = row_id(await checks.call("create_ghostwriter_project", clientId=client_id,
                            codename=name, projectTypeId=int(project_type["id"]),
                            startDate=today, endDate=today))
        owned["project"].append(project_id)
        report_id = row_id(await checks.call("create_ghostwriter_report", projectId=project_id, title=name))
        owned["report"].append(report_id)
        report_fields = {
            "executive_summary": RICH, "business_impact": "<p>Preserve sibling section.</p>",
            "engagement_goals": RICH, "scope_narrative": RICH, "scope_exclusions": RICH,
            "scope_addendum": "Synthetic fixture only", "network_map": RICH,
            "security_strengths": RICH, "areas_of_improvement": RICH, "attack_chain": RICH,
            "additional_appendix": RICH, "previous_findings": [],
        }
        await checks.call("update_ghostwriter_report_extra_fields", reportId=report_id, extraFields=report_fields)
        await asyncio.gather(
            checks.call("update_ghostwriter_report_extra_fields", reportId=report_id,
                        extraFields={"executive_summary": "<p>Updated executive summary.</p>"}),
            checks.call("update_ghostwriter_report_extra_fields", reportId=report_id,
                        extraFields={"scope_narrative": "<p>Updated scope.</p>"}),
        )
        report_fields.update(executive_summary="<p>Updated executive summary.</p>",
                             scope_narrative="<p>Updated scope.</p>")
        await checks.call("update_ghostwriter_report_extra_fields", reportId=report_id,
                          extraFields={"scope_addendum": ""})
        report_fields["scope_addendum"] = ""
        stored = await persisted("report", report_id)
        require(all(stored["extraFields"].get(key) == value for key, value in report_fields.items()),
                "Report custom-section merge lost a sibling or update")
        finding_type_id = int(lookups["findingTypes"][0]["id"])
        for severity in SEVERITIES:
            custom = {"impact_rating": severity, "likelihood_rating": "Medium",
                      "mitre_attack": "T1083", "mitre_mitigation": "M1027"}
            finding_id = row_id(await checks.call(
                "create_ghostwriter_finding", title=f"{prefix} {severity} (safe to delete)",
                description=RICH, severityId=severities[severity], findingTypeId=finding_type_id,
                replication_steps=RICH, impact="<p>Library impact.</p>",
                mitigation="<p>Library mitigation.</p>", extraFields=custom,
                cvssScore=9.3, cvssVector=CVSS4,
            ))
            owned["finding"].append(finding_id)
            original = await persisted("finding", finding_id)
            require(original["extraFields"] == custom, "Library custom fields were not stored")
            require(int(original["severityId"]) == severities[severity], "Severity was not stored")
            require(original["cvssVector"] == CVSS4 and float(original["cvssScore"]) == 9.3,
                    "CVSS 4.0 values were not stored")
            attached = one(await checks.call("attach_finding_to_report", finding=finding_id, reportId=report_id))
            reported_id = int(attached["reportedFindingId"])
            require(reported_id > 0, "Attach returned no report finding ID")
            owned["reportedFinding"].append(reported_id)
            require(int(attached["usedFindingId"]) == finding_id, "Attached the wrong library finding")
            copy = await persisted("reportedFinding", reported_id)
            for field in ("title", "description", "impact", "mitigation", "replication_steps", "extraFields"):
                require(copy[field] == original[field], f"Attach did not copy {field}")
            await checks.call("update_report_finding", reportedFindingId=reported_id,
                              replicationSteps="<p>Engagement-specific steps.</p>",
                              affectedEntities="<p>192.0.2.10</p>")
            await checks.call("update_report_finding", reportedFindingId=reported_id,
                              title=f"{prefix} {severity} tailored (safe to delete)")
            await asyncio.gather(
                checks.call("update_ghostwriter_report_finding_extra_fields", reportedFindingId=reported_id,
                            extraFields={"impact_rating": "High"}),
                checks.call("update_ghostwriter_report_finding_extra_fields", reportedFindingId=reported_id,
                            extraFields={"likelihood_rating": "Low"}),
            )
            tailored = await persisted("reportedFinding", reported_id)
            expected_custom = {**custom, "impact_rating": "High", "likelihood_rating": "Low"}
            require(tailored["extraFields"] == expected_custom, "Finding merge lost a sibling or update")
            require(tailored["replication_steps"] == "<p>Engagement-specific steps.</p>",
                    "Partial title update erased replication steps")
            require(tailored["affectedEntities"] == "<p>192.0.2.10</p>",
                    "Partial title update erased affected entities")
            for field in ("description", "impact", "mitigation", "cvssScore", "cvssVector", "severityId"):
                require(tailored[field] == original[field], f"Partial update changed unrelated {field}")
            if severity == "UNKNOWN":
                rerated = one(await checks.call(
                    "update_report_finding", reportedFindingId=reported_id,
                    severityId=severities["High"], cvssScore=8.7, cvssVector=CVSS4,
                ))
                require(rerated.get("affected_rows") == 1, "Re-rating did not update one report finding")
                rerated = await persisted("reportedFinding", reported_id)
                require(int(rerated["severityId"]) == severities["High"]
                        and float(rerated["cvssScore"]) == 8.7 and rerated["cvssVector"] == CVSS4,
                        "UNKNOWN report finding was not re-rated with CVSS 4.0")
                require(rerated["extraFields"] == expected_custom
                        and rerated["replication_steps"] == tailored["replication_steps"]
                        and rerated["affectedEntities"] == tailored["affectedEntities"],
                        "Re-rating erased report-specific fields")
            require(await persisted("finding", finding_id) == original, "Tailoring altered the library template")
            extra = one(await checks.call("get_ghostwriter_report_finding_extra_fields",
                                          reportedFindingId=reported_id))
            require(extra["extraFields"] == expected_custom, "MCP custom-field read disagrees with storage")
        absent = 2147483000
        # Prove this synthetic sentinel is absent before testing failed mutations.
        import ghostwriter_api as gw

        payload = await gw._post("query ($id: bigint!) { report(where: {id: {_eq: $id}}) { id } "
                                 "reportedFinding(where: {id: {_eq: $id}}) { id } }", {"id": absent})
        require(not payload["data"]["report"] and not payload["data"]["reportedFinding"],
                "Missing-ID sentinel unexpectedly exists")
        await checks.call("update_report_finding", expect_error=True,
                          reportedFindingId=absent, title="ZZ MCP absent")
        for tool, argument in (("get_ghostwriter_report_extra_fields", "reportId"),
                               ("update_ghostwriter_report_extra_fields", "reportId"),
                               ("get_ghostwriter_report_finding_extra_fields", "reportedFindingId"),
                               ("update_ghostwriter_report_finding_extra_fields", "reportedFindingId")):
            arguments = {argument: absent}
            if tool.startswith("update_"):
                arguments["extraFields"] = {"executive_summary" if argument == "reportId" else "impact_rating": "Absent"}
            await checks.call(tool, expect_error=True, **arguments)
        first_id = owned["reportedFinding"][0]
        await checks.call("delete_ghostwriter_report_finding", expect_error=True, reportedFindingId=first_id)
        await checks.call("delete_ghostwriter_report_finding", expect_error=True,
                          reportedFindingId=first_id, confirmId=first_id + 1)
        require(row_id(await persisted("reportedFinding", first_id)) == first_id,
                "Delete confirmation guard removed a record")
        print("PASS acceptance: six severities, CVSS 4.0, attach/copy, partial edits, re-rating, custom-field merges/clearing, error guards")
    finally:
        for entity, identifiers in owned.items():
            tool, argument = delete_tools[entity]
            for identifier in reversed(identifiers):
                try:
                    deleted = one(await checks.call(tool, **{argument: identifier, "confirmId": identifier}))
                    require(deleted.get("deleted") is True and int(deleted["id"]) == identifier,
                            "Delete did not confirm the owned record")
                except Exception:  # noqa: BLE001 - continue cleaning the remaining owned fixtures
                    cleanup_errors.append(f"{entity} {identifier}")
        if cleanup_errors:
            raise AssertionError("Cleanup failed for owned fixtures: " + ", ".join(cleanup_errors))
        print("PASS cleanup: removed only fixtures created by this run")


async def run(args):
    params = StdioServerParameters(command=sys.executable, args=[args.server], env=dict(os.environ))
    # Server logs stay private; test failure messages never include tool payloads
    # or HTTP headers. Normal MCP protocol output still passes through its pipes.
    with tempfile.TemporaryFile(mode="w+") as errors:
        async with stdio_client(params, errlog=errors) as (read, write):  # noqa: SIM117
            async with ClientSession(read, write, read_timeout_seconds=60) as session:
                initialized = await session.initialize()
                info = getattr(initialized, "server_info", getattr(initialized, "serverInfo", None))
                require(info and info.name, "MCP initialization returned no server identity")
                available = {tool.name for tool in (await session.list_tools()).tools}
                require(REQUIRED_TOOLS <= available,
                        "Missing MCP tools: " + ", ".join(sorted(REQUIRED_TOOLS - available)))
                print(f"PASS MCP initialize/list-tools: {len(available)} tools")
                checks = Checks(session)
                try:
                    lookups, severities = await read_only(checks, args)
                    if args.write:
                        await acceptance(checks, lookups, severities)
                finally:
                    if args.write:
                        import ghostwriter_api as gw

                        await gw.close_client()
                print(f"PASS MCP smoke: {checks.calls} tool calls, {checks.expected_errors} expected protocol errors")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true", help="Create and clean up disposable acceptance fixtures")
    parser.add_argument("--server", default="/opt/cptc/server.py")
    parser.add_argument("--config", default="/seed/config.py")
    parser.add_argument("--client-name", default=os.getenv("MCP_TEST_CLIENT_NAME"))
    parser.add_argument("--project-codename", default=os.getenv("MCP_TEST_PROJECT_CODENAME"))
    parser.add_argument("--report-title", default=os.getenv("MCP_TEST_REPORT_TITLE"))
    args = parser.parse_args()
    try:
        asyncio.run(run(args))
    except Exception as exc:  # noqa: BLE001 - report nested protocol failures without secrets
        # Assertion messages are ours and contain no API response bodies.
        def failure_summary(error):
            if isinstance(error, BaseExceptionGroup):
                return "; ".join(failure_summary(child) for child in error.exceptions)
            return str(error) if isinstance(error, AssertionError) else type(error).__name__

        detail = failure_summary(exc)
        token = os.getenv("GHOSTWRITER_API_TOKEN", "")
        if token:
            detail = detail.replace(token, "[REDACTED]")
        print(f"FAIL MCP smoke: {detail}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

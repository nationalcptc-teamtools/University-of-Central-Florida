"""Exercise pinned MCP candidates against the disposable CPTC lab.

The URL is deliberately fixed to loopback. Use only the separate gw-mcp-eval
stack. Credentials come from an owner-only JSON file, never from arguments.
This program initially inventories tools; --calls supplies an explicit JSON
list of {name, arguments, case} tool calls. Results are evidence, not a score:
success also requires database/read-back validation by the evaluator.
"""
import argparse
import asyncio
import json
import os
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(__file__).resolve().parent


async def run(args):
    candidates = json.loads((ROOT / "candidates.json").read_text())
    candidate = candidates[args.candidate]
    checkout = Path(args.checkouts).resolve() / args.candidate
    credentials = json.loads(Path(args.credentials).read_text())
    assert credentials["url"] == "http://127.0.0.1:18080/v1/graphql"
    env = dict(os.environ)
    env.update({
        "GHOSTWRITER_GRAPHQL_URL": credentials["url"],
        "GHOSTWRITER_URL": credentials["url"],
        "GHOSTWRITER_API_TOKEN": credentials["token"],
        "GHOSTWRITER_TLS_INSECURE": "0",
        "GHOSTWRITER_PAGINATION_LIMIT": "50",
        "GHOSTWRITER_REQUEST_TIMEOUT": "15",
        "PYTHON_DOTENV_DISABLED": "1",
    })
    params = StdioServerParameters(
        command=str(checkout / ".venv/bin/python"),
        args=[str(checkout / candidate["entrypoint"])],
        cwd=str(checkout), env=env,
    )
    output = {"candidate": args.candidate, "commit": candidate["commit"], "calls": []}
    path = Path(args.output)
    path.parent.mkdir(parents=True, exist_ok=True)
    def save():
        serialized = json.dumps(output, indent=2).replace(credentials["token"], "[REDACTED]")
        path.write_text(serialized + "\n")

    with path.with_suffix(".stderr.log").open("w") as errlog:
        try:
            async with stdio_client(params, errlog=errlog) as (read, write):
                async with ClientSession(read, write, read_timeout_seconds=30) as session:
                    init = await session.initialize()
                    output["initialize"] = init.model_dump(mode="json")
                    tools = await session.list_tools()
                    output["tools"] = [t.model_dump(mode="json") for t in tools.tools]
                    calls = json.loads(Path(args.calls).read_text()) if args.calls else []
                    for call in calls:
                        try:
                            result = await session.call_tool(call["name"], call.get("arguments", {}))
                            record = {**call, "result": result.model_dump(mode="json")}
                        except Exception as exc:
                            record = {**call, "exception": str(exc)}
                        output["calls"].append(record)
                        print(args.candidate, call.get("case", call["name"]), flush=True)
                        save()
        except Exception as exc:
            output["startup_error"] = str(exc)
    # Remove the test credential even if a server accidentally echoes it.
    save()
    print(args.candidate, "tools:", len(output.get("tools", [])), "calls:", len(output["calls"]))
    return 1 if output.get("startup_error") else 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate", choices=json.loads((ROOT / "candidates.json").read_text()))
    parser.add_argument("--checkouts", required=True)
    parser.add_argument("--credentials", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--calls")
    raise SystemExit(asyncio.run(run(parser.parse_args())))

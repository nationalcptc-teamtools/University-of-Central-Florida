# CPTC MCP evaluation

The first evaluation used the repository's Ghostwriter v7.2.6 images, current
seed configuration, and three pinned community servers. See [RESULTS.md](RESULTS.md)
for the recommendation and [results/](results/) for tool responses, database
read-back, dependency locks, and image digests. This directory is a test harness;
it does not install an MCP into the normal Ghostwriter stack.

## Scope

The baseline exercises the actual stdio MCP protocol, then real GraphQL calls
against an isolated database. Each candidate has independent synthetic fixtures,
so a broken create tool does not prevent testing its read or update tools. IDs
come from this deployment, including its UNKNOWN severity. Tests use an ordinary
Ghostwriter API token belonging to a lab admin, matching the eight admin accounts
in the CPTC seed. They do not use the Hasura administrator secret.

No LLM/provider account is needed. Model-specific tool selection, multi-user
concurrency, remote MCP transport, restricted service tokens, and performance
under competition load are outside this first comparison. Dependency adjustments
are recorded separately from application behaviour. Candidate source was not patched.

## Reproduce the baseline

Requirements: Docker Compose supporting `!override`, Python 3.12, and `uv`.
The lab publishes only `127.0.0.1:18080`, uses project `gw-mcp-eval` and separate
volumes, and does not start nginx. The existing application stack is untouched.
Use a fresh destination and clean evaluation volumes. If repeating this run,
save its outputs and run `compose_eval down --volumes` from the previous lab
directory first. That removes the previous evaluation data. The fixed project
name and port deliberately allow only one evaluation at a time; stopping alone
retains its database and is insufficient for a fresh baseline.

From this repository:

```bash
repo_dir="$PWD"
eval_dir="$HOME/.cache/ghostwriter-mcp-eval-new"
python3 test/mcp/prepare_lab.py "$eval_dir/lab"
cd "$eval_dir/lab"
compose_eval() {
  docker compose -p gw-mcp-eval -f docker-compose.yml \
    -f docker-compose.override.yml -f compose.eval.yml "$@"
}
compose_eval up -d --wait --wait-timeout 240 \
  postgres redis django graphql_engine collab-server queue
umask 077
compose_eval exec -T django python /app/manage.py shell < seed/seed.py > seed-private.log 2>&1
compose_eval exec -T django python /app/manage.py shell < "$repo_dir/test/mcp/init_token.py"
docker cp gw-mcp-eval-django-1:/tmp/mcp-eval-credentials.json "$eval_dir/credentials.json"
chmod 600 "$eval_dir/credentials.json"
compose_eval exec -T django python /app/manage.py shell < "$repo_dir/test/mcp/fixtures.py"
docker cp gw-mcp-eval-django-1:/tmp/mcp-fixtures.json "$eval_dir/fixtures.json"
cd "$repo_dir"
```

Clone each URL in `candidates.json` to `$eval_dir/candidates/<owner>`, check out
the recorded commit, and create a Python 3.12 `.venv` inside each checkout. For
the exact tested dependency environments, install the corresponding
`results/<owner>-requirements.lock` with `uv pip install --python .venv/bin/python`.
These are evaluation snapshots, not recommendations to leave dependencies frozen
indefinitely. To assess pristine installation instead, install each upstream
`requirements.txt` first and capture its startup failure before applying the
adjustment in `candidates.json`.

```bash
python3 test/mcp/build_cases.py "$eval_dir/fixtures.json" "$eval_dir/cases"
for candidate in lsr00ter PaulDHaes ayoubbenmakker; do
  "$eval_dir/candidates/lsr00ter/.venv/bin/python" test/mcp/probe.py "$candidate" \
    --checkouts "$eval_dir/candidates" \
    --credentials "$eval_dir/credentials.json" \
    --calls "$eval_dir/cases/$candidate-calls.json" \
    --output "$eval_dir/results/$candidate.json"
done
docker exec -i gw-mcp-eval-django-1 python /app/manage.py shell < test/mcp/verify_records.py
docker cp gw-mcp-eval-django-1:/tmp/mcp-readback.json "$eval_dir/results/readback.json"
```

`probe.py` records results rather than converting candidate failures into an
overall passing test. Review both `is_error` and response content: two candidates
return GraphQL failures inside nominally successful MCP results. Missing features
are distinct from failed calls. For lsr00ter's upstream unit suite, run
`.venv/bin/python -m unittest discover -s tests` in its checkout.

The saved evidence also includes supplemental checks: explicit report dates and
minimal findings for PaulDHaes; complete-field updates for ayoubbenmakker; attachment
of all six MCP-created library findings and CVSS v4 storage for lsr00ter; and
omitted-field preservation. Their exact arguments are in the result JSONs. IDs
belong to the recorded run and must be remapped to new fixture/creation IDs when
repeating those checks.

## Historical template checks

The current repository intentionally excludes DOCX templates. The evaluation
recovered three historical files from the parent of deletion commit `e63a09a`
into the external lab directory; they were not restored to the maintained tree.
The exact source commit is in `results/environment.json`.

Copy those files to `/tmp/mcp-templates` in the Django container, attach the six
MCP-created findings to the lsr00ter fixture report using its MCP tools, and run:

```bash
docker exec -i gw-mcp-eval-django-1 python /app/manage.py shell < test/mcp/export_templates.py
docker exec -i gw-mcp-eval-django-1 python /app/manage.py shell < test/smoke.py
docker cp gw-mcp-eval-django-1:/tmp/mcp-exports "$eval_dir/exports"
```

The export helper calls Ghostwriter's platform exporter. It does not imply the
MCP has a report-generation tool. The existing smoke script separately proves
Regionals styles and severity colours. The helpers do not inspect the document
visually or establish that these historical templates match today's manually
uploaded versions.

## Stop the lab

Run `compose_eval stop` from the lab directory after testing. This preserves the
isolated volumes and exports for investigation. The token from `init_token.py`
expires after four hours. Keep credential files, private seed output, external
checkouts, and binary templates outside Git. The first run's token was revoked
after evidence capture.

"""Run through manage.py shell ONLY inside the disposable gw-mcp-eval lab.

Creates independent fixtures so a failed create operation does not prevent
testing the candidate's search, attachment, or update tools. Writes fixture IDs
to /tmp/mcp-fixtures.json inside the container. No production data is used.
"""
import datetime
import json
from pathlib import Path

from django.contrib.auth import get_user_model
from ghostwriter.reporting.models import Finding, FindingType, Report, ReportFindingLink, Severity
from ghostwriter.rolodex.models import Client, Project, ProjectType

RICH = "<p>ZZ MCP synthetic reporting fixture.</p><ul><li>first bullet</li></ul><ol><li>step one</li></ol><p>Inline <code>sample</code>.</p><pre><code>sample output</code></pre><blockquote>A quoted note</blockquote>"
EXTRA = {"impact_rating": "High", "likelihood_rating": "Medium", "mitre_attack": "T1083", "mitre_mitigation": "M1027"}
user = get_user_model().objects.get(username="admin")
ptype = ProjectType.objects.get(project_type="Penetration Test")
ftype = FindingType.objects.first()
severity = Severity.objects.get(severity="High")
out = {"project_type": ptype.pk, "finding_type": ftype.pk,
       "severities": list(Severity.objects.order_by("weight").values("id", "severity")),
       "rich": RICH, "extra": EXTRA, "candidates": {}}
for owner in ["lsr00ter", "PaulDHaes", "ayoubbenmakker"]:
    name = f"ZZ MCP {owner} fixture (safe to delete)"
    client = Client.objects.create(name=name, short_name="ZZTEST", codename=f"ZZ-{owner}")
    project = Project.objects.create(client=client, codename=name, project_type=ptype,
        start_date=datetime.date(2026, 11, 7), end_date=datetime.date(2026, 11, 7), operator=user)
    report = Report.objects.create(title=name, project=project, created_by=user,
        extra_fields={"executive_summary": "<p>Preserve this summary.</p>",
                      "business_impact": "<p>Preserve this sibling field.</p>"})
    finding = Finding.objects.create(title=name, severity=severity, finding_type=ftype,
        description=RICH, impact="<p>Original impact</p>", mitigation="<p>Original mitigation</p>",
        replication_steps=RICH, extra_fields=EXTRA)
    reported = ReportFindingLink.objects.create(title=name, report=report, severity=severity,
        finding_type=ftype, assigned_to=user, description=RICH,
        impact="<p>Original impact</p>", mitigation="<p>Original mitigation</p>",
        replication_steps=RICH, extra_fields=EXTRA,
        affected_entities="<p>192.0.2.10 must survive an unrelated update.</p>")
    out["candidates"][owner] = {"client": client.pk, "project": project.pk,
        "report": report.pk, "finding": finding.pk, "reported_finding": reported.pk}
Path("/tmp/mcp-fixtures.json").write_text(json.dumps(out, indent=2))
print("Created disposable candidate fixtures.")

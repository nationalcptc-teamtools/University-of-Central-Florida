"""Prepare a fresh isolated configuration without changing the normal stack."""
import argparse
import re
import secrets
import shutil
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("destination", type=Path)
args = parser.parse_args()
repo = Path(__file__).resolve().parents[2]
lab = args.destination.resolve()
if lab == repo or repo in lab.parents:
    parser.error("Use a destination outside the repository")
if lab.exists():
    parser.error("Destination already exists; use a fresh evaluation directory")
shutil.copytree(repo, lab, ignore=shutil.ignore_patterns(
    ".git", ".env", ".mcp", "credentials.txt", "ssl", "__pycache__", "results"))
env = re.sub(r"^([A-Z_]+)=<generated>$", lambda m: m[1]+"="+secrets.token_hex(25),
             (repo/".env.example").read_text(), flags=re.M)
env = env.replace("HEALTHCHECK_INTERVAL='300s'", "HEALTHCHECK_INTERVAL='5s'")
env = env.replace("HEALTHCHECK_START='60s'", "HEALTHCHECK_START='180s'")
env = env.replace("HEALTHCHECK_RETRIES='3'", "HEALTHCHECK_RETRIES='24'")
env = env.replace("DJANGO_SECURE_SSL_REDIRECT='true'", "DJANGO_SECURE_SSL_REDIRECT='false'")
(lab/".env").write_text(env)
(lab/".env").chmod(0o600)
(lab/"compose.eval.yml").write_text('''services:
  graphql_engine:
    ports:
      - "127.0.0.1:18080:8080"
  django:
    environment:
      WEB_CONCURRENCY: "2"
  nginx:
    ports: !override []
''')
print(lab)

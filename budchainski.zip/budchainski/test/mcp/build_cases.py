"""Generate equivalent reporting exercises for the three different tool APIs."""
import argparse
import json
from pathlib import Path


def cases(owner, fixture):
    ids = fixture["candidates"][owner]
    rich, extra = fixture["rich"], fixture["extra"]
    prefix = f"ZZ MCP {owner}"
    result = []

    def add(case, tool_name, **arguments):
        result.append({"case": case, "name": tool_name, "arguments": arguments})

    if owner == "ayoubbenmakker":
        add("discover_clients", "list_clients")
        add("discover_projects", "list_projects")
        add("discover_reports", "list_reports_for_project", project_id=ids["project"])
        add("discover_library", "search_library_findings", title_query=prefix)
        add("read_project", "get_project", project_id=ids["project"])
        add("read_report_findings", "list_findings_for_project", project_id=ids["project"])
        add("create_client", "create_client", name=prefix+" created (safe to delete)", codename=prefix)
        add("create_project", "create_project", client_id=ids["client"], codename=prefix+" created",
            start_date="2026-11-07", end_date="2026-11-07")
        add("create_report", "create_report", project_id=ids["project"], title=prefix+" created (safe to delete)")
        for severity in fixture["severities"]:
            add("create_finding_"+severity["severity"], "create_finding", report_id=ids["report"],
                title=prefix+" "+severity["severity"]+" (safe to delete)", severity_id=severity["id"],
                description=rich, impact="<p>Test impact</p>", mitigation="<p>Test mitigation</p>",
                references=["https://example.com/reporting-fixture"], affected_entities=["192.0.2.10"])
        add("partial_update", "update_report_finding", finding_id=ids["reported_finding"], title=prefix+" edited")
        add("missing_row_error", "update_report_finding", finding_id=2147483000, title="ZZ MCP absent")
        add("report_custom_summary", "update_executive_summary", report_id=ids["report"], executive_summary=rich)
        add("generate_report", "generate_report", report_id=ids["report"])
        return result

    for entity in ["clients", "projects", "reports", "findings"]:
        add("discover_"+entity, "search_ghostwriter_"+entity, search_term=prefix)
    if owner == "lsr00ter":
        add("lookup_ids", "list_ghostwriter_lookups")
    for entity in ["client", "project", "report"]:
        key = entity+"Id" if owner == "lsr00ter" else entity+"_id"
        add("read_"+entity, "get_ghostwriter_"+entity+"_by_id", **{key: ids[entity]})
    add("read_report_findings", "list_report_finding", reportId=ids["report"])
    key = "shortName" if owner == "lsr00ter" else "short_name"
    add("create_client", "create_ghostwriter_client", name=prefix+" created (safe to delete)",
        codename=prefix, **{key: "ZZTEST"})
    add("create_project", "create_ghostwriter_project", clientId=ids["client"],
        codename=prefix+" created", projectTypeId=fixture["project_type"], startDate="2026-11-07", endDate="2026-11-07")
    add("create_report", "create_ghostwriter_report", projectId=ids["project"], title=prefix+" created (safe to delete)")
    for severity in fixture["severities"]:
        fields = {"extraFields" if owner == "lsr00ter" else "extra_fields": extra}
        if owner == "lsr00ter":
            fields.update(impact="<p>Test impact</p>", mitigation="<p>Test mitigation</p>",
                          references="<p>https://example.com/reporting-fixture</p>")
        add("create_finding_"+severity["severity"], "create_ghostwriter_finding",
            title=prefix+" "+severity["severity"]+" (safe to delete)", description=rich,
            severityId=severity["id"], findingTypeId=fixture["finding_type"],
            replication_steps=rich, cvssScore=7.5, cvssVector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", **fields)
    add("attach_library", "attach_finding_to_report", finding=ids["finding"], reportId=ids["report"])
    idkey = "reportedFindingId" if owner == "lsr00ter" else "findingId"
    add("partial_update", "update_report_finding", **{idkey:ids["reported_finding"]}, replicationSteps=rich+"<p>Edited steps</p>")
    add("missing_row_error", "update_report_finding", **{idkey:2147483000}, replicationSteps="<p>ZZ MCP absent</p>")
    if owner == "lsr00ter":
        add("rerate_finding", "update_report_finding", reportedFindingId=ids["reported_finding"],
            severityId=fixture["severities"][0]["id"], cvssScore=9.1, complete=True)
        add("delete_confirmation_guard", "delete_ghostwriter_report_finding", reportedFindingId=ids["reported_finding"])
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("fixtures"); p.add_argument("output_directory")
    args = p.parse_args()
    fixture = json.loads(Path(args.fixtures).read_text())
    out = Path(args.output_directory); out.mkdir(parents=True, exist_ok=True)
    for owner in fixture["candidates"]:
        (out/(owner+"-calls.json")).write_text(json.dumps(cases(owner, fixture), indent=2)+"\n")

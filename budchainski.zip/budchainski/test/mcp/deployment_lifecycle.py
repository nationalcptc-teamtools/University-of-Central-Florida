#!/usr/bin/env python3
"""Exercise real MCP credential lifecycle only in an explicitly named test stack.

Run this HOST-side from an isolated repository copy with COMPOSE_FILE and
COMPOSE_PROJECT_NAME pointing at its running lab, for example:

    python3 test/mcp/deployment_lifecycle.py --project-name gw-mcp-deployment-test

This rotates/revokes only the configured MCP identity's managed test tokens.
Subprocess output and token values are never printed. The final state contains
one valid managed token and a usable local MCP client configuration.
"""

from __future__ import annotations

import argparse
import json
import os
import stat
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TOKEN = ROOT / ".mcp/token"
MARKER = "MCP_LIFECYCLE\t"

# Inputs are prepended through stdin. Return metadata only: neither tokens nor
# stored credential hashes enter this subprocess's JSON output.
INSPECT = r'''
import json
import runpy
from datetime import timedelta
from django.contrib.auth import get_user_model
from django.utils import timezone
from ghostwriter.api.models import APIKey

settings = runpy.run_path("/seed/config.py").get("MCP", {})
username = settings.get("username", "ghostwriter-mcp")
user = get_user_model().objects.get(username=username)
managed = APIKey.objects.filter(user=user, name="CPTC MCP (managed by up.sh)")
if MCP_TEST_ACTION == "expire":
    key = APIKey.objects.get_valid_from_token(MCP_TEST_TOKENS[0])
    if key.user_id != user.pk or key.name != "CPTC MCP (managed by up.sh)":
        raise ValueError("Expiry target is not the configured managed MCP token")
    managed.filter(pk=key.pk).update(expiry_date=timezone.now() - timedelta(days=1))
elif MCP_TEST_ACTION != "inspect":
    raise ValueError("Unexpected test action")
valid = []
for token in MCP_TEST_TOKENS:
    try:
        key = APIKey.objects.get_valid_from_token(token)
        valid.append(key.user_id == user.pk and key.name == "CPTC MCP (managed by up.sh)")
    except APIKey.DoesNotExist:
        valid.append(False)
print("MCP_LIFECYCLE\t" + json.dumps({
    "username": user.username,
    "role": user.role,
    "is_active": user.is_active,
    "is_staff": user.is_staff,
    "is_superuser": user.is_superuser,
    "usable_password": user.has_usable_password(),
    "active_count": managed.filter(revoked=False).count(),
    "valid": valid,
}))
'''


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def captured(command, *, source=None, timeout=180):
    return subprocess.run(
        command, cwd=ROOT, input=source, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, timeout=timeout, check=False,
    )


def guard_project(expected):
    require("test" in expected.lower() and expected != "ghostwriter_sys",
            "Refusing lifecycle writes: --project-name must name an isolated test project")
    result = captured(["docker", "compose", "config", "--format", "json"])
    require(result.returncode == 0,
            "Cannot resolve Compose configuration; set the isolated lab's Compose environment")
    resolved = json.loads(result.stdout)
    require(resolved.get("name") == expected,
            "Refusing lifecycle writes: resolved Compose name does not match --project-name")
    result = captured(["docker", "compose", "ps", "--status", "running", "-q", "django"])
    containers = result.stdout.split()
    require(result.returncode == 0 and len(containers) == 1,
            "Expected exactly one running Django container in the isolated test stack")
    result = captured([
        "docker", "inspect", "--format",
        '{{ index .Config.Labels "com.docker.compose.project" }}', containers[0],
    ])
    require(result.returncode == 0 and result.stdout.strip() == expected,
            "Refusing lifecycle writes: Django container belongs to a different Compose project")


def configure(*flags):
    result = captured([sys.executable, "mcp/configure.py", *flags])
    action = flags[0] if flags else "provision"
    require(result.returncode == 0,
            f"MCP configure {action} failed (exit {result.returncode}; private output suppressed)")


def local_token():
    require(TOKEN.is_file() and not TOKEN.is_symlink(), "Managed local token file is missing")
    token = TOKEN.read_text().strip()
    require(bool(token) and not any(char.isspace() for char in token),
            "Managed local token file is empty or malformed")
    require(stat.S_IMODE(TOKEN.stat().st_mode) == 0o600, "Local token must have mode 0600")
    require(stat.S_IMODE(TOKEN.parent.stat().st_mode) == 0o700,
            "Local MCP directory must have mode 0700")
    require(TOKEN.stat().st_uid == os.getuid(), "Local token is owned by another host user")
    client_path = TOKEN.parent / "client.json"
    require(client_path.is_file() and stat.S_IMODE(client_path.stat().st_mode) == 0o600,
            "Private local MCP client configuration is missing or has the wrong mode")
    client = json.loads(client_path.read_text())["mcpServers"]["ghostwriter"]
    require(client.get("command") == str(ROOT / "mcp/run.sh") and client.get("args") == [],
            "Client configuration does not point to this lab's launcher")
    return token


def inspect(tokens, *, action="inspect"):
    source = f"MCP_TEST_TOKENS = {tokens!r}\nMCP_TEST_ACTION = {action!r}\n" + INSPECT
    result = captured([
        "docker", "compose", "exec", "-T", "django", "python", "/app/manage.py", "shell",
    ], source=source)
    require(result.returncode == 0,
            "Django credential metadata check failed (private output suppressed)")
    payloads = [json.loads(line[len(MARKER):]) for line in result.stdout.splitlines()
                if line.startswith(MARKER)]
    require(len(payloads) == 1, "Django did not return one credential metadata result")
    return payloads[0]


def active_token(token, *, invalid=()):
    info = inspect([token, *invalid])
    require(info["role"] == "manager" and info["is_active"],
            "MCP identity must be an active manager")
    require(not info["is_staff"] and not info["is_superuser"] and not info["usable_password"],
            "MCP identity must have no staff, superuser, or interactive password privileges")
    require(info["valid"] == [True, *([False] * len(invalid))],
            "Current credential is invalid or a retired credential still works")
    require(info["active_count"] == 1, "Expected exactly one unrevoked managed credential")


def exercise():
    configure()
    initial = local_token()
    active_token(initial)
    print("PASS initial provisioning: active manager, no interactive/admin privileges, private files")

    configure()
    require(local_token() == initial, "Repeated provisioning changed a healthy credential")
    active_token(initial)
    print("PASS repeated provisioning: healthy credential reused")

    configure("--rotate")
    rotated = local_token()
    require(rotated != initial, "Explicit rotation reused the old credential")
    active_token(rotated, invalid=(initial,))
    print("PASS rotation: replacement valid, old credential invalid")

    with ThreadPoolExecutor(max_workers=2) as workers:
        futures = [workers.submit(configure, "--rotate") for _ in range(2)]
        for future in futures:
            future.result()
    concurrent = local_token()
    require(concurrent != rotated, "Concurrent rotations did not replace the credential")
    active_token(concurrent, invalid=(initial, rotated))
    print("PASS concurrent rotations: both completed, saved credential valid, one active managed token")

    configure("--revoke")
    require(not TOKEN.exists(), "Revocation did not remove the local token")
    info = inspect([initial, rotated, concurrent])
    require(not any(info["valid"]) and info["active_count"] == 0,
            "Revocation left a managed credential valid or unrevoked")
    print("PASS revocation: local token removed and all prior credentials invalid")

    configure()
    enabled = local_token()
    active_token(enabled, invalid=(initial, rotated, concurrent))
    print("PASS re-enable: new valid credential after revocation")

    expired = inspect([enabled], action="expire")
    require(expired["valid"] == [False], "Synthetic expiry did not invalidate the test credential")
    configure()
    recovered = local_token()
    require(recovered != enabled, "Setup reused an expired credential")
    active_token(recovered, invalid=(initial, rotated, concurrent, enabled))
    print("PASS expiry recovery: setup replaced the expired credential")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-name", required=True,
                        help="Exact isolated Compose project name; must contain 'test'")
    args = parser.parse_args()
    try:
        # All writes, including best-effort restoration, remain behind this guard.
        guard_project(args.project_name)
        try:
            exercise()
        finally:
            configure()
            active_token(local_token())
        print("PASS MCP credential lifecycle: integration left enabled with one valid managed token")
        return 0
    except Exception as exc:  # noqa: BLE001 - suppress potentially secret subprocess errors
        # Never expose subprocess output, API responses, arguments containing
        # credentials, or arbitrary exception payloads in test failure output.
        detail = str(exc) if isinstance(exc, AssertionError) else type(exc).__name__
        print(f"FAIL MCP credential lifecycle: {detail}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

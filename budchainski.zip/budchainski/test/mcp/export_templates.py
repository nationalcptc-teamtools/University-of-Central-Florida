"""Export the MCP-populated report using historical CPTC DOCX templates.

Run only inside the disposable lab after copying the historical templates to
/tmp/mcp-templates. This tests the platform exporter separately because the
leading candidates do not expose an export tool. Template-specific smoke checks
are also run separately. Nothing here changes the MCP candidates.
"""
import io
import json
import traceback
import zipfile
from pathlib import Path

from django.contrib.auth import get_user_model
from django.core.files import File
from lxml import etree
from ghostwriter.reporting.models import Report, ReportTemplate, DocType
from ghostwriter.commandcenter.models import ReportConfiguration
from ghostwriter.modules.reportwriter.report.docx import ExportReportDocx

out = Path("/tmp/mcp-exports"); out.mkdir(exist_ok=True)
report = Report.objects.get(title="ZZ MCP lsr00ter fixture (safe to delete)")
results = []
for path in sorted(Path("/tmp/mcp-templates").glob("*.docx")):
    template = ReportTemplate(name="ZZ MCP historical "+path.stem, doc_type=DocType.objects.get(doc_type="docx"),
        uploaded_by=get_user_model().objects.get(username="admin"))
    with path.open("rb") as f:
        template.document.save(path.name, File(f), save=True)
    result = {"template": path.name, "template_id": template.pk}
    try:
        blob = ExportReportDocx(report, report_template=template).run().getvalue()
        (out/path.name).write_bytes(blob)
        document = etree.fromstring(zipfile.ZipFile(io.BytesIO(blob)).read("word/document.xml"))
        text = "".join(document.itertext())
        probes = ["first bullet", "step one", "sample output", "A quoted note", "T1083", "M1027"]
        result.update(exported=True, bytes=len(blob), probes={p: p in text for p in probes})
    except Exception as exc:
        result.update(exported=False, error=str(exc), traceback=traceback.format_exc()[-1800:])
    results.append(result)
    if path.name == "cptc-regionals.docx":
        config = ReportConfiguration.get_solo()
        config.default_docx_template = template
        config.save()
(out/"results.json").write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))

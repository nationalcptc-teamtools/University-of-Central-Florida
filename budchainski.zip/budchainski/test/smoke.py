"""Prove the seeded instance can actually produce a report.

Builds a throwaway client/project/report with one finding per severity, each
containing the rich-text constructs a real finding uses (bulleted list,
numbered list, code block, inline code, blockquote), exports it through the
default template, and asserts the output is correct. Everything happens inside
a transaction that is always rolled back.

Why this exists and the linter is not enough: Ghostwriter's linter renders with
EMPTY finding bodies, so it never applies the list styles. A template missing
"Bullet List" lints perfectly clean and then raises KeyError on the first
finding that contains a bullet. That exact bug shipped once already.

    docker compose exec -T django python /app/manage.py shell < test/smoke.py
"""
import datetime
import sys
import traceback
import zipfile

from django.contrib.auth import get_user_model
from django.db import transaction
from lxml import etree

from ghostwriter.commandcenter.models import ReportConfiguration
from ghostwriter.modules.reportwriter.report.docx import ExportReportDocx
from ghostwriter.reporting.models import (
    FindingType, Report, ReportFindingLink, Severity)
from ghostwriter.rolodex.models import Client, Project, ProjectType

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

RICH = """
<p>Prose before the list.</p>
<ul><li>first bullet</li><li>second bullet</li></ul>
<ol><li>step one</li><li>step two</li></ol>
<p>Inline <code>whoami</code> here.</p>
<pre><code>curl -s http://10.0.1.11/ | head</code></pre>
<blockquote>A quoted note.</blockquote>
"""

failures = []
blob = None


def check(condition, message):
    if not condition:
        failures.append(message)


class Rollback(Exception):
    pass


template = ReportConfiguration.get_solo().default_docx_template
if template is None:
    sys.exit("smoke: no default DOCX template configured - upload a template and "
             "set it as the default under Report Configuration first")

user = get_user_model().objects.filter(is_superuser=True).order_by("id").first()
if user is None:
    sys.exit("smoke: no superuser exists")

# UNKNOWN is a library placeholder; operators assign a real severity before
# exporting. The private template deliberately omits UNKNOWN detail sections.
severities = list(Severity.objects.filter(severity__in=(
    "Critical", "High", "Medium", "Low", "Informational")).order_by("weight"))
if len(severities) != 5:
    sys.exit("smoke: expected all five reportable severities")

try:
    with transaction.atomic():
        client = Client.objects.create(name="__smoke client", short_name="SMOKE")
        project = Project.objects.create(
            client=client, codename="__SMOKE",
            project_type=ProjectType.objects.first(),
            start_date=datetime.date(2026, 1, 1),
            end_date=datetime.date(2026, 1, 2),
            operator=user)
        report = Report.objects.create(
            title="__smoke report", project=project, created_by=user,
            docx_template=template)

        finding_type = FindingType.objects.first()
        for position, severity in enumerate(severities, start=1):
            ReportFindingLink.objects.create(
                report=report, title=f"__smoke {severity.severity}",
                severity=severity, finding_type=finding_type,
                assigned_to=user, position=position,
                cvss_score="9.1", cvss_vector="AV:N/AC:L",
                affected_entities="<p>10.0.1.11</p>",
                description=RICH, impact=RICH, mitigation=RICH,
                replication_steps=RICH, references=RICH,
                extra_fields={
                    "impact_rating": severity.severity,
                    "likelihood_rating": severity.severity,
                    "mitre_attack": "T1190",
                    "mitre_mitigation": "M1051",
                })

        blob = ExportReportDocx(report, report_template=template).run().getvalue()
        raise Rollback()
except Rollback:
    pass
except Exception:
    print(traceback.format_exc()[-3000:])
    sys.exit("smoke: export raised - see traceback above")

# --- inspect the produced document -----------------------------------------
import io

body = etree.fromstring(
    zipfile.ZipFile(io.BytesIO(blob)).read("word/document.xml")
).find(W + "body")
text = "".join(body.itertext())

# Rich-text content survived the HTML -> docx conversion.
for probe in ("first bullet", "step one", "curl -s http", "whoami", "A quoted note"):
    check(probe in text, f"rich text missing from export: {probe!r}")
for probe in ("T1190", "M1051"):
    check(probe in text, f"MITRE extra field missing from export: {probe!r}")

# The styles Ghostwriter applies to that content exist in the template.
applied = set()
for para in body.iter(W + "p"):
    pPr = para.find(W + "pPr")
    if pPr is not None:
        style = pPr.find(W + "pStyle")
        if style is not None:
            applied.add(style.get(W + "val"))
for run in body.iter(W + "r"):
    rPr = run.find(W + "rPr")
    if rPr is not None:
        style = rPr.find(W + "rStyle")
        if style is not None:
            applied.add(style.get(W + "val"))

for style in ("BulletList", "NumberList", "CodeBlock", "CodeInline", "Blockquote"):
    check(style in applied, f"style never applied in export: {style} "
                            "(template is probably missing it)")

# Summary shading follows the seeded palette. Heading accents are a design
# choice in the private template (e.g. a darker green for Low), not DB colours.
expected = {s.severity: s.color.upper() for s in severities}

shaded = set()
for table in body.iter(W + "tbl"):
    rows = table.findall(W + "tr")
    if not rows or "Vuln ID" not in "".join(rows[0].itertext()):
        continue
    for row in rows[1:]:
        cells = row.findall(W + "tc")
        label = "".join(cells[-1].itertext()).strip()
        shd = cells[-1].find(W + "tcPr").find(W + "shd")
        fill = (shd.get(W + "fill") if shd is not None else "").upper()
        shaded.add(label)
        check(fill == expected.get(label),
              f"summary table {label}: shading #{fill}, expected #{expected.get(label)}")
check(shaded == set(expected), f"summary table severities {shaded} != {set(expected)}")

headed = set()
for para in body.iter(W + "p"):
    label = "".join(para.itertext()).strip()
    if "__smoke " not in label:
        continue
    pPr = para.find(W + "pPr")
    style = pPr.find(W + "pStyle") if pPr is not None else None
    if style is None or style.get(W + "val") != "Heading3":
        continue
    severity = label.split("__smoke ", 1)[1].strip()
    headed.add(severity)
check(headed == set(expected), f"finding headings {headed} != {set(expected)}")

# Nothing leaked out of the rolled-back transaction.
check(Client.objects.filter(name__startswith="__smoke").count() == 0,
      "rollback failed: smoke client still present")
check(Report.objects.filter(title__startswith="__smoke").count() == 0,
      "rollback failed: smoke report still present")

print()
if failures:
    print(f"SMOKE FAILED - {len(failures)} problem(s):")
    for failure in failures:
        print("  x", failure)
    sys.exit(1)
print(f"SMOKE PASSED - exported {len(blob):,} bytes through "
      f"{template.name!r}, {len(severities)} severities, styles and colours correct")

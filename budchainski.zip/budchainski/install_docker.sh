#!/bin/bash

set -euo pipefail

curl -fsSL get.docker.com | sh
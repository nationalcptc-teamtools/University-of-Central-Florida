#!/usr/bin/env python3
"""Provision a dedicated Ghostwriter MCP token and local stdio client config."""
import argparse
import fcntl
import json
import os
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATE = ROOT / ".mcp"
TOKEN = STATE / "token"
MARKER = "MCP_CREDENTIAL\t"


def write_private(destination, value):
    fd, temporary = tempfile.mkstemp(prefix=".pending-", dir=STATE)
    try:
        with os.fdopen(fd, "w") as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, destination)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def django(action, token, rotate=False):
    inputs = (f"MCP_ACTION = {action!r}\n"
              f"MCP_EXISTING_TOKEN = {token!r}\n"
              f"MCP_ROTATE = {rotate!r}\n")
    result = subprocess.run(
        ["docker", "compose", "exec", "-T", "django", "python",
         "/app/manage.py", "shell"], cwd=ROOT,
        input=inputs + (ROOT / "seed/mcp_token.py").read_text(),
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, check=False)
    lines = result.stdout.splitlines()
    payloads = [json.loads(line[len(MARKER):]) for line in lines
                if line.startswith(MARKER)]
    output = "\n".join(line for line in lines if not line.startswith(MARKER))
    for secret in [token, *(payload["token"] for payload in payloads)]:
        if secret:
            output = output.replace(secret, "[REDACTED]")
    if result.returncode:
        if output:
            print(output, file=sys.stderr)
        raise RuntimeError("MCP credential configuration failed")
    if action == "provision":
        if len(payloads) != 1 or not payloads[0].get("token"):
            raise RuntimeError("Django did not return one managed MCP credential")
        return payloads[0]
    if output:
        print(output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    flags = parser.add_mutually_exclusive_group()
    flags.add_argument("--rotate", action="store_true")
    flags.add_argument("--revoke", action="store_true")
    args = parser.parse_args()
    try:
        if STATE.is_symlink() or TOKEN.is_symlink():
            parser.error(".mcp and .mcp/token must not be symbolic links")
        STATE.mkdir(mode=0o700, exist_ok=True)
        STATE.chmod(0o700)
        lock_fd = os.open(STATE / "configure.lock", os.O_CREAT | os.O_RDWR, 0o600)
        with os.fdopen(lock_fd, "a+") as lock:
            # Serialize provision -> persist -> retire, including revocation.
            # Otherwise parallel setup can leave the last saved token revoked.
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            if TOKEN.exists():
                if not stat.S_ISREG(TOKEN.stat().st_mode):
                    parser.error(".mcp/token must be a regular file")
                TOKEN.chmod(0o600)
            token = TOKEN.read_text().strip() if TOKEN.exists() else ""
            if args.revoke:
                django("revoke", token)
                TOKEN.unlink(missing_ok=True)
                print("Local MCP token removed; run --mcp-setup to enable MCP again.")
                return
            credential = django("provision", token, args.rotate)
            # Retire old tokens only AFTER the new credential is safely on disk.
            write_private(TOKEN, credential["token"] + "\n")
            django("finalize", credential["token"])
            client = {"mcpServers": {"ghostwriter": {
                "command": str(ROOT / "mcp/run.sh"), "args": []}}}
            write_private(STATE / "client.json", json.dumps(client, indent=2) + "\n")
            print(f"MCP account: {credential['username']} (manager; no interactive password)")
            print(f"MCP token {'renewed' if credential['renewed'] else 'reused'}; "
                  f"expires {credential['expires']}")
            print(f"Client configuration: {STATE / 'client.json'}")
    except PermissionError:
        sys.exit("MCP state is owned by another host user. Run setup and the MCP "
                 "client as the same user; inspect .mcp ownership before retrying.")
    except (OSError, RuntimeError, ValueError) as exc:
        sys.exit(str(exc))


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
# Use the absolute path to this launcher in any stdio MCP client.
set -euo pipefail
cd "$(dirname "$0")/.."
exec ./ghostwriter.sh --mcp

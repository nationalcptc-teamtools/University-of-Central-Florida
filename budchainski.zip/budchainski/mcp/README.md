# Ghostwriter MCP deployment

`./ghostwriter.sh` installs the evaluated [lsr00ter/Ghostwriter-mcp](https://github.com/lsr00ter/Ghostwriter-mcp)
at commit `44a5cbf40940085797fa3a404370911360dbbefa`. The upstream archive is
checksum-verified and Python dependencies are fixed in `requirements.lock`.
The upstream modules stay unmodified; `server.py` adds the CPTC custom-field
tools. The earlier comparison is in [test/mcp/RESULTS.md](../test/mcp/RESULTS.md).

Host requirements are Docker with Compose v2, Python 3, Bash, and OpenSSL.
There is no host virtualenv, LLM account, or provider key to configure.

## Set up and connect

For a fresh installation:

```bash
./ghostwriter.sh
```

For an existing running Ghostwriter installation:

```bash
./ghostwriter.sh --mcp-setup
```

Both commands build the MCP image, configure its credential, and run the
read-only smoke test. Each teammate then follows the
[client setup guide](CLIENTS.md) for Codex, OpenCode, Claude Code, Cursor,
VS Code/Copilot, or Claude Desktop. It includes local and SSH instructions,
verification commands, and troubleshooting. Configuration formats differ:
the generated `.mcp/client.json` is a `mcpServers` example for compatible
JSON clients, while Codex uses TOML and OpenCode uses its own `mcp` schema.

No token belongs in the client config. The launcher changes into the correct
repository even when the client starts from another directory. It runs
`docker compose run --rm --no-deps -T`, with the host user's UID/GID so the
container can read the owner's private token. Run setup and the client launcher
as the same host user, including the SSH user for a remote client. It starts on demand for each
connection and exits when the client disconnects. The Compose `mcp` profile
keeps it out of ordinary `docker compose up` service startup.

For a client on another computer, the guide shows how to launch the same
command through non-interactive SSH. Teammates need no local Docker or copy
of the deployment token for that connection.

The MCP uses `http://graphql_engine:8080/v1/graphql` on the Compose network,
so it does not need to trust the web interface's self-signed certificate or
disable TLS verification. It publishes no port. Ghostwriter must already
be running; the client launcher does not start or reconfigure the stack.

## Credentials and repeated setup

`seed/config.py` defines the managed MCP username and token lifetime under
`MCP`. The default `ghostwriter-mcp` account has role `manager`, access to
all engagements, no Django staff/superuser status, and an unusable login
password. It uses a normal Ghostwriter API token, never the Hasura admin secret.
Existing interactive accounts are rejected rather than repurposed.

This is one shared account for all clients using this deployment. Each client
starts its own process, but Ghostwriter receives the same manager credential;
it does not identify or restrict callers by teammate. SSH keys and AI-provider
logins do not change the Ghostwriter identity. The launcher reads `.mcp/token`
even if a different token is present in the client's environment. Per-user
token selection is not implemented. For concurrent-edit behavior and a
six-person team's coordination rules, see
[Credentials and six-person editing](CLIENTS.md#credentials-and-six-person-editing).

`.mcp/token` is stored with permissions 0600 under a 0700 directory. Setup
reuses a valid token until it approaches expiry, then saves a replacement
atomically before revoking older tokens belonging to this managed integration.
It does not rotate teammates' tokens or change their accounts. Changing the
MCP username creates a different account; revoke the old account's managed
token before switching usernames.

```bash
./ghostwriter.sh --mcp-test          # read-only initialize, tools, lookup and report checks
./ghostwriter.sh --mcp-rotate-token  # replace token and test it
./ghostwriter.sh --mcp-revoke-token  # revoke integration tokens and remove the local token
./ghostwriter.sh --mcp-setup         # re-enable/rebuild/renew and test
```

Restart connected clients after rotating or revoking a token: each process
loads the token when it starts. `--down` preserves credentials and Docker
volumes. A revoked or expired token produces a tool error until setup renews it.

## CPTC tools

The upstream tools manage clients, projects, reports, library findings,
report attachments, narrative edits, severity and CVSS ratings. Search and
lookup IDs before creating records. An attached finding is a report-specific
copy; engagement edits belong on that copy.

The deployment adapts report creation to the manager role's permitted fields;
Ghostwriter's database supplies the report's update date automatically.

The deployment also adds report-copy reads for severity and narrative, alongside
the custom-field tools in `seed/config.py`:

| Tool | Arguments |
| --- | --- |
| `get_ghostwriter_report_extra_fields` | `reportId` |
| `update_ghostwriter_report_extra_fields` | `reportId`, `extraFields` |
| `get_ghostwriter_report_finding_extra_fields` | `reportedFindingId` |
| `update_ghostwriter_report_finding_extra_fields` | `reportedFindingId`, `extraFields` |
| `list_ghostwriter_report_findings` | `reportId` |
| `list_ghostwriter_finding_field_specs` | none |
| `get_ghostwriter_report_finding_by_id` | `reportedFindingId` |
| `list_ghostwriter_report_evidence` | `reportId` |
| `get_ghostwriter_evidence_image` | `reportId`, `evidenceId` |
| `view_ghostwriter_evidence_image` | `reportId`, `evidenceId` |

`list_ghostwriter_report_findings` returns the attached copies with their
`severityId`, position, CVSS score/vector, and custom fields. Match `severityId`
to `list_ghostwriter_lookups`.
`list_ghostwriter_finding_field_specs` shows the custom fields in the web editor,
including each internal name, label, type, and position. The manager GraphQL
role has no `extraFieldSpec` mutation, so field-spec changes require Django
maintenance. Run `seed/migrate_mitre.py` explicitly to convert simple ATT&CK
HTML values to plain text and remove the duplicate web field specification;
historical legacy values stay in stored finding JSON.
`get_ghostwriter_report_finding_by_id` reads the report copy's description,
impact, replication steps, affected entities, CVSS values, and custom fields.
Use the report-copy ID from a list result, not a findings-library ID.
Finding rich text embeds evidence IDs as `data-evidence-id`. List the report's
evidence to inspect captions and file names, then read supported PNG, JPEG,
GIF, or WebP images by ID. The MCP receives the media volume read-only and
returns image bytes as base64 with a MIME type; each read is limited to an
8 MiB image under that report's evidence directory.
`view_ghostwriter_evidence_image` returns an MCP image block for clients that
display image content directly, with the same report and size checks.

For example, call the report update tool with:

```json
{
  "reportId": 123,
  "extraFields": {"executive_summary": "<p>The assessment identified...</p>"}
}
```

Use the actual report ID returned by search. The mutation uses Hasura's atomic
JSONB `_append` operation, so other keys such as `business_impact` remain in
place even during simultaneous edits to different sections. Each supplied
key's value is replaced, including a nested JSON object or array; this is a
shallow merge. Pass an empty string to clear a text field. Use only fields
defined for the deployment. HTML rich text follows Ghostwriter's normal
Jinja escaping rules. Missing IDs and failed writes produce MCP protocol errors.
The report-finding ATT&CK single-line text key is `mitre_attack`.

Evidence uploads, DOCX/PPTX generation, and operation logs are not exposed
by this MCP. Use the Ghostwriter UI for those operations. The export smoke
test (`./ghostwriter.sh --test`) remains separate and requires an uploaded default
report template.

## Acceptance testing

`./ghostwriter.sh --mcp-test` does not write application records. It checks the real
stdio handshake/tool inventory, all six severities, the seeded engagement,
and reading custom fields.

The optional write suite creates its own uniquely named disposable engagement
and findings, verifies persisted data independently through GraphQL, and cleans
up only records it created. Run it in an isolated Compose project with fresh
volumes, never against the engagement used for competition:

```bash
docker compose run --rm --no-deps -T --user "$(id -u):$(id -g)" \
  mcp /opt/cptc/deployment_smoke.py --write
```

It covers all six severities, finding attachment, rich text, CVSS v4,
partial-update preservation, custom report sections, report-only MITRE edits,
concurrent sibling-section updates, nonexistent IDs, delete confirmation,
and cleanup. The write suite requires the managed manager token and a seeded
deployment. Docker project/override settings must be the same as setup.

To prepare a completely separate test deployment from this checkout:

```bash
mcp_test_root="$(mktemp -d)"
python3 test/mcp/prepare_lab.py "$mcp_test_root/lab"
cd "$mcp_test_root/lab"
export COMPOSE_PROJECT_NAME="gw-mcp-deployment-test-$(date +%s)"
export COMPOSE_FILE=docker-compose.yml:docker-compose.override.yml:compose.eval.yml
./ghostwriter.sh
docker compose run --rm --no-deps -T --user "$(id -u):$(id -g)" \
  mcp /opt/cptc/deployment_smoke.py --write
python3 test/mcp/deployment_lifecycle.py --project-name "$COMPOSE_PROJECT_NAME"
./ghostwriter.sh --mcp-test
docker compose stop
```

The lab helper excludes credentials, generates fresh secrets, publishes GraphQL
only on loopback port 18080, and disables nginx's published ports. Ensure no other
evaluation is using 18080. The lifecycle suite refuses the normal deployment
project, exercises reuse/rotation/revocation/expiry/concurrent rotations, and
finishes with one valid token. `stop` retains the lab's files and Docker volumes.

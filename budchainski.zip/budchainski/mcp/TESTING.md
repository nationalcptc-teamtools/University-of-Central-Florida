# MCP deployment validation

Validated October 19, 2026 against Ghostwriter v7.2.6 in a separate Compose
project, `gw-mcp-deployment-test`, with its own database and media volumes.
No team engagement was used for write testing.

Runtime inputs:

- Upstream MCP: `lsr00ter/Ghostwriter-mcp`, commit
  `44a5cbf40940085797fa3a404370911360dbbefa`.
- Python 3.12 slim Bookworm image index:
  `sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258`.
- Dependencies: the complete exact-version `mcp/requirements.lock`; container
  `pip check` passed.
- Credential: ordinary API token for the dedicated `manager` account, with
  neither Django staff/superuser privileges nor an interactive password.

Results:

| Check | Result |
| --- | --- |
| Full `./ghostwriter.sh` start, seed, build, token provisioning, read-only MCP test | Passed |
| Real MCP initialize/list-tools | 26 tools |
| Default read-only smoke | Passed, 9 tool calls |
| Write acceptance | Passed, 81 total tool calls including 7 expected protocol errors |
| Six severities, rich text, four custom finding fields | Persisted and independently read back |
| Library attach and report-only edits | Library entry preserved |
| UNKNOWN-to-High re-rating and CVSS 4.0 storage | Passed |
| Twelve report sections, field clearing, concurrent sibling-key updates | Passed |
| Missing-ID errors and delete confirmation guards | Passed |
| Fixture cleanup | Only this run's created IDs removed |
| Host launcher started from `/tmp` | Real initialize, 26 tools, authenticated lookup passed |
| Token reuse, rotation, revocation, re-enable, expiry recovery | Passed |
| Two concurrent token rotations | Both succeeded; saved token valid; one active managed token |
| File permissions and account properties | 0700 directory, 0600 files, non-interactive manager |
| Runtime extension unit suite inside built image | 16 tests passed |
| Pinned upstream unit suite | 77 tests passed |
| New Python lint, shell syntax, diff whitespace | Passed |

The lab uses loopback-only web/GraphQL ports and a longer startup healthcheck
grace period for initial migrations. The test helper now applies that grace
period automatically. Production port bindings and application healthcheck
settings remain the deployment's existing values.

Reproduction commands are in [README.md](README.md#acceptance-testing).
Private tokens and runtime logs remain outside Git. These checks cover the
MCP protocol and stored application data; no LLM provider was required. Evidence
uploads and document export remain UI operations and were not added as MCP
tools. The repository's separate template-export smoke test was not rerun for
this deployment change.

# Connect your AI client to Ghostwriter

This guide covers Codex, OpenCode, Claude Code, Cursor, VS Code/Copilot, and
Claude Desktop. Each teammate configures their own AI client. The deployment
administrator runs Ghostwriter and provisions the MCP once on its Docker host.

Read [Credentials and six-person editing](#credentials-and-six-person-editing)
before using the shared deployment: the current launcher uses one shared
Ghostwriter manager identity, even when everyone has their own client config.

## Choose where your client runs

| Your setup | Command your MCP client starts |
| --- | --- |
| Client runs on the Ghostwriter Docker host, under the user who ran setup | Absolute path to `mcp/run.sh` |
| Client runs on your laptop or another machine | `ssh` to the Docker host, running that same launcher |

The examples use `/absolute/path/to/cptc-26-ghostwriter` for the checkout on the
Docker host and `ghostwriter-team` for an SSH alias. Replace the path and alias
with your deployment's values. The GitLab server address is not necessarily
the Ghostwriter Docker host.

This is command-based stdio MCP. The Ghostwriter website and `/v1/graphql`
are not MCP URLs. A teammate using SSH needs their AI client and an SSH client;
Docker, Python, the checkout, and the Ghostwriter token stay on the Docker host.

## Administrator: set up the Docker host once

On a new installation, run `./ghostwriter.sh` from the checkout. On an existing running
installation, run:

```bash
cd /absolute/path/to/cptc-26-ghostwriter
./ghostwriter.sh --mcp-setup
./ghostwriter.sh --mcp-test
```

Both full setup and `--mcp-setup` build the image and run the read-only MCP
check. The pinned deployment currently exposes 26 tools. Share the host name,
deployment OS username, and absolute checkout path with teammates. Authorize
their SSH public keys through the host's normal access-management process.
The SSH user must be the same OS user that owns this checkout's `.mcp/` state,
and must be able to use Docker without an interactive sudo/password prompt.

For a custom Compose project, create a host-side wrapper that sets the same
`COMPOSE_FILE` and `COMPOSE_PROJECT_NAME` used for setup before calling
`mcp/run.sh`; configure clients to launch that wrapper. The standard deployment
needs no Compose environment overrides. More host details: [deployment guide](README.md).

## Teammate: verify SSH first

Skip this section when your AI client runs directly on the Docker host.
On your own computer, merge an entry like this into `~/.ssh/config`:

```sshconfig
Host ghostwriter-team
    HostName ghostwriter.example.internal
    User DEPLOY_USER
    IdentityFile ~/.ssh/id_ed25519
    IdentitiesOnly yes
```

Use the host, OS user, and private-key path appropriate for you. Connect once
interactively to establish host trust and, if needed, load your private key
into your SSH agent. Verify the host fingerprint with the administrator.
Then test non-interactive access:

```bash
ssh ghostwriter-team true
ssh -T -o BatchMode=yes ghostwriter-team \
  '/absolute/path/to/cptc-26-ghostwriter/ghostwriter.sh --mcp-test'
```

The second command must succeed without prompting. `-T` preserves stdio;
`BatchMode=yes` makes missing key/agent access fail immediately. Keep the host
key check enabled. The client must run in the same OS environment where this
SSH configuration and agent work.

## Codex CLI and IDE extension

Choose one command:

```bash
# Client runs on the Docker host:
codex mcp add ghostwriter -- /absolute/path/to/cptc-26-ghostwriter/mcp/run.sh

# Client runs on your laptop:
codex mcp add ghostwriter -- ssh -T -o BatchMode=yes ghostwriter-team /absolute/path/to/cptc-26-ghostwriter/mcp/run.sh
```

Alternatively, merge this SSH example into `~/.codex/config.toml`:

```toml
[mcp_servers.ghostwriter]
command = "ssh"
args = ["-T", "-o", "BatchMode=yes", "ghostwriter-team", "/absolute/path/to/cptc-26-ghostwriter/mcp/run.sh"]
startup_timeout_sec = 60
tool_timeout_sec = 60
```

For a local TOML entry, use the launcher path as `command` and `args = []`.
If you used `mcp add`, add `startup_timeout_sec = 60` to its existing table
when Docker/SSH startup exceeds the default timeout. Do not add a duplicate table.

Run `codex mcp list` and `codex mcp get ghostwriter`, then start a new session
and inspect `/mcp`. Restart the IDE extension after changing its configuration.
Use the Codex configuration, not the generated `.mcp/client.json` JSON file.
[Official Codex MCP documentation](https://learn.chatgpt.com/docs/extend/mcp?surface=cli).

## OpenCode

Merge into user-wide `~/.config/opencode/opencode.json` or project
`opencode.json`:

```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "ghostwriter": {
      "type": "local",
      "command": ["ssh", "-T", "-o", "BatchMode=yes", "ghostwriter-team", "/absolute/path/to/cptc-26-ghostwriter/mcp/run.sh"],
      "enabled": true,
      "timeout": 60000
    }
  }
}
```

On the Docker host, use `"command": ["/absolute/path/to/cptc-26-ghostwriter/mcp/run.sh"]`.
Keep `type` as `local` for SSH too: OpenCode is launching a process rather than
connecting to an MCP HTTP URL. The timeout is in milliseconds.

Run `opencode mcp list`, then start a new OpenCode session. This client uses
`mcp` and a command array, not the generated `mcpServers` JSON format. Enable
the entry with `enabled: true`; `mcp auth`/`mcp debug` are for OAuth workflows.
[Official MCP docs](https://opencode.ai/docs/mcp-servers/),
[config locations](https://opencode.ai/docs/config/).

## Claude Code

Choose one command:

```bash
# Client runs on the Docker host:
claude mcp add --transport stdio --scope user ghostwriter -- /absolute/path/to/cptc-26-ghostwriter/mcp/run.sh

# Client runs on your laptop:
claude mcp add --transport stdio --scope user ghostwriter -- ssh -T -o BatchMode=yes ghostwriter-team /absolute/path/to/cptc-26-ghostwriter/mcp/run.sh
```

`--scope user` makes the entry available across your projects. Use
`--scope project` instead if you deliberately want a shared project
`.mcp.json`; project entries require first-use approval. The `--` keeps SSH
options separate from Claude's options.

Run `claude mcp list` and `claude mcp get ghostwriter`, then open a new Claude
Code session and inspect `/mcp`. If startup times out, launch with
`MCP_TIMEOUT=60000 claude` (milliseconds). Keep normal tool approval prompts.
[Official Claude Code MCP documentation](https://code.claude.com/docs/en/mcp).

## Cursor

Merge into user-wide `~/.cursor/mcp.json` or project `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "ghostwriter": {
      "type": "stdio",
      "command": "ssh",
      "args": ["-T", "-o", "BatchMode=yes", "ghostwriter-team", "/absolute/path/to/cptc-26-ghostwriter/mcp/run.sh"]
    }
  }
}
```

On the Docker host, set `command` to the absolute launcher path and `args`
to `[]`. Enable Ghostwriter in Cursor's MCP settings/Customize view and check
its tools; connection errors appear in Output under MCP logs.
[Official Cursor MCP documentation](https://cursor.com/docs/mcp).

## VS Code / GitHub Copilot

In the Command Palette, select **MCP: Add Server**, choose **Command (stdio)**,
and register either the local launcher or the SSH command above. Select the
user/workspace destination offered by your installed version. Use
**MCP: List Servers** to start/restart Ghostwriter and inspect its output.

Current Copilot portable user configuration uses `~/.copilot/mcp-config.json`
when `COPILOT_HOME` is unset; otherwise use `$COPILOT_HOME/mcp-config.json`.
Merge the following shape with any existing entries:

```json
{
  "mcpServers": {
    "ghostwriter": {
      "command": "ssh",
      "args": ["-T", "-o", "BatchMode=yes", "ghostwriter-team", "/absolute/path/to/cptc-26-ghostwriter/mcp/run.sh"]
    }
  }
}
```

For a local server, use the launcher path as `command` and `args: []`.
Existing VS Code `.vscode/mcp.json` files use a different compatibility format:

```json
{
  "servers": {
    "ghostwriter": {
      "type": "stdio",
      "command": "ssh",
      "args": ["-T", "-o", "BatchMode=yes", "ghostwriter-team", "/absolute/path/to/cptc-26-ghostwriter/mcp/run.sh"]
    }
  }
}
```

Use the format for the selected file; the Command Palette flow avoids mixing
them. [Official setup guide](https://code.visualstudio.com/docs/agent-customization/mcp-servers),
[configuration reference](https://code.visualstudio.com/docs/agents/reference/mcp-configuration).

## Claude Desktop and other stdio clients

In Claude Desktop, open **Settings → Developer → Edit Config** and merge:

```json
{
  "mcpServers": {
    "ghostwriter": {
      "command": "ssh",
      "args": ["-T", "-o", "BatchMode=yes", "ghostwriter-team", "/absolute/path/to/cptc-26-ghostwriter/mcp/run.sh"]
    }
  }
}
```

Fully quit and reopen Desktop. On macOS the file is
`~/Library/Application Support/Claude/claude_desktop_config.json`; on Windows
it is `%APPDATA%\Claude\claude_desktop_config.json`. Use **Edit Config** to
locate it rather than guessing for other installations. Check Ghostwriter in
the chat input's connectors menu under **Manage connectors**.
[Official local-server setup guide](https://modelcontextprotocol.io/docs/develop/connect-local-servers).

Other command-based stdio clients use the same command and arguments, but may
use a different config schema. The host-generated `.mcp/client.json` is a
local-host `mcpServers` example, not a universal import file. For SSH, use the
example above. Claude web custom connectors require an MCP URL and do not
execute this laptop/host SSH configuration.

## Windows and WSL

The Bash launcher runs on the Linux/macOS Docker host. Native Windows clients
can use Windows OpenSSH to reach that host; the path in the SSH arguments is
the remote Linux/macOS path. For a local WSL deployment, run the CLI client
inside the same WSL environment, where its checkout, Docker access, SSH keys,
and config paths are available. A native Windows application cannot launch
`run.sh` directly. [OpenCode's WSL guidance](https://opencode.ai/docs/windows-wsl/).

## Verify and troubleshoot

After the client reports a connection, ask:

> Use Ghostwriter to list the severity lookup values and find the existing
> Southeast X Penetration Test report. Do not create or edit anything.

Use the report title from `seed/config.py` if your administrator changed it.
This tests actual tool access without modifying the report.

| Symptom | Check |
| --- | --- |
| SSH asks for a password or fails in batch mode | Confirm the alias, deployment OS user, authorized key, and unlocked SSH agent in the same environment as the client. |
| `Permission denied` reading the MCP token or using Docker | Use the OS user who ran setup and confirm that user's non-interactive Docker access. |
| `MCP is not configured` | Administrator runs `./ghostwriter.sh --mcp-setup` on the deployment host. |
| Startup times out | Run the SSH smoke command above; increase the client's startup/discovery timeout to 60 seconds. |
| JSON-RPC parse errors | Keep shell banners/debug `echo` output off non-interactive stdout; use `ssh -T`. |
| GUI client cannot find `ssh` | Use the absolute executable path in `command` and restart the app. |
| Tools reject a previously working token | Administrator renews with `--mcp-setup`; reconnect clients afterward. |
| Configured server is missing | Use the client's correct config format, approve/enable the server, and restart the client. |

MCP auth/login commands for OAuth do not log this stdio integration into a
personal Ghostwriter account. Model-provider subscriptions/API keys belong to
each AI client and are separate from Ghostwriter credentials.

## Credentials and six-person editing

The current authentication path is:

```text
Each teammate's AI client → its own MCP container → Ghostwriter GraphQL
                                     ↑
                       same host .mcp/token file
                       owner: ghostwriter-mcp (manager)
```

Each connection starts an independent container, so using one token does not
force all six people into one interactive session. The token authenticates
parallel API requests. Ghostwriter authenticates them as `ghostwriter-mcp`,
not as the teammate's named Ghostwriter login. SSH keys control host access;
they do not select the Ghostwriter user.

| Concurrent work | Behavior |
| --- | --- |
| Different report findings | Updates target separate `reportedFindingId` records. |
| Different narrative fields on the same finding | The update sends only supplied fields; unrelated fields are retained. |
| Different custom-field keys on the same finding/report | Atomic top-level JSONB merges preserve the other keys. |
| Same field or same custom-field key | The last committed write wins; an older draft can overwrite a newer value. |
| Two edits within one rich-text field, JSON array, or nested value | The supplied field/key value is replaced as a whole, not collaboratively merged. |
| Individual ownership/attribution | The shared manager token provides no per-teammate identity or "only my findings" enforcement. |

Agree on one owner for a finding while it is being edited, verify the report
and finding IDs, and send only the fields being changed. Attach a library
finding once, then tailor the report copy; keep engagement details out of the
shared library. Assignments in the UI help coordinate work, but the manager
token is not restricted to the assigned operator. These tools send API field
updates rather than collaborative text-edit operations, with no expected-version
condition or edit lock.

The existing acceptance suite verifies concurrent custom-field updates. A
six-client competition-load benchmark has not been performed. Per-person
Ghostwriter API tokens would improve attribution, permissions, and individual
revocation; they would still require coordination on shared fields.

Currently every launcher reads the host's `.mcp/token` and sets the API
credential from it. Adding a personal token to a client's environment does not
override that behavior. Per-user credential selection is not implemented.
The shared token expires after 30 days by default; rotation/revocation affects
all clients using this checkout, and each must reconnect to load a replacement.
See [credential management](README.md#credentials-and-repeated-setup).

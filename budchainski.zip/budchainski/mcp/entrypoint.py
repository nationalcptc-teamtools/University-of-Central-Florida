"""Load the private bind-mounted token, then launch the requested Python file."""
import os
import sys
from pathlib import Path


def main():
    token_file = Path(os.environ.get(
        "GHOSTWRITER_API_TOKEN_FILE", "/run/ghostwriter-mcp/token"))
    try:
        token = token_file.read_text().strip()
    except OSError:
        sys.exit("MCP token is unavailable; run ./ghostwriter.sh --mcp-setup on the Docker host.")
    if not token or any(char.isspace() for char in token):
        sys.exit("MCP token file is empty or invalid; run ./ghostwriter.sh --mcp-setup.")
    os.environ["GHOSTWRITER_API_TOKEN"] = token
    if not sys.argv[1:]:
        sys.exit("A Python script is required.")
    os.execv(sys.executable, [sys.executable, *sys.argv[1:]])


if __name__ == "__main__":
    main()

"""Pinned upstream Ghostwriter MCP with CPTC custom-field tools.

Upstream lives separately on PYTHONPATH. The report-create compatibility wrapper
lets PostgreSQL supply last_update, which the manager role cannot set directly.
The custom-field extensions use Hasura's atomic
JSONB ``_append`` operator: only supplied top-level keys change, so editing an
executive summary cannot replace an independently edited business-impact field.
Values for a supplied key are replaced, including nested JSON objects.
"""

from __future__ import annotations

import base64
import os
from pathlib import Path
from typing import Any

import ghostwriter_api as gw
from main import WRITE, _tool_error, server
from mcp.server.mcpserver import Image
from mcp.server.mcpserver.exceptions import ToolError
from mcp.types import ToolAnnotations

READ_ONLY = ToolAnnotations(
    readOnlyHint=True, destructiveHint=False, idempotentHint=True, openWorldHint=True
)
UPDATE = ToolAnnotations(
    readOnlyHint=False, destructiveHint=True, idempotentHint=True, openWorldHint=True
)


# Upstream inserts last_update even when callers omit it. This deployment's
# manager role cannot write that column; migration 0063 supplies CURRENT_DATE.
# Override the tool at composition time, preserving the archived source modules.
server.remove_tool("create_ghostwriter_report")


@server.tool(title="Create report", annotations=WRITE)
async def create_ghostwriter_report(title: str, projectId: int) -> dict[str, Any]:
    """Create a report linked to an existing project and return its reportId.

    Search reports first to avoid duplicates. projectId comes from project
    search or creation. Ghostwriter supplies the report's last_update date;
    this deployment's manager role cannot set that field during creation.
    """
    try:
        result = await gw._post(
            """mutation CPTCCreateReport($object: report_insert_input!) {
              insert_report_one(object: $object) {
                id title projectId last_update
              }
            }""",
            {"object": {
                "title": gw._require_text(title, "title"),
                "projectId": gw._require_positive_int(projectId, "projectId"),
            }},
        )
        report = (result.get("data") or {}).get("insert_report_one")
        if not report:
            raise gw.GhostwriterError("Failed to create report - no data returned")
        return {
            "id": report["id"],
            "title": report["title"],
            "projectId": report["projectId"],
            "last_update": report["last_update"],
            "_workflow_note": "Save this 'id' as reportId for attach_finding_to_report",
        }
    except Exception as exc:
        raise _tool_error("create_ghostwriter_report", exc) from exc


def _positive_id(value: int, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise gw.GhostwriterValidationError(f"{name} must be a positive integer")
    return value


def _fields(value: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(value, dict) or not value:
        raise gw.GhostwriterValidationError("extraFields must be a non-empty JSON object")
    if any(not isinstance(key, str) or not key.strip() for key in value):
        raise gw.GhostwriterValidationError("extraFields keys must be non-empty strings")
    return value


async def _read_extra_fields(table: str, row_id: int) -> dict[str, Any]:
    # Table names and selections come exclusively from the four tools below.
    selection = "id title extraFields" + (" reportId" if table == "reportedFinding" else "")
    result = await gw._post(
        f"""query CPTCExtraFields($id: bigint!) {{
          {table}(where: {{id: {{_eq: $id}}}}, limit: 1) {{ {selection} }}
        }}""",
        {"id": row_id},
    )
    rows = (result.get("data") or {}).get(table) or []
    if not rows:
        raise gw.GhostwriterNotFoundError(f"No accessible {table} with id {row_id}.")
    return rows[0]


async def _update_extra_fields(
    table: str, row_id: int, fields: dict[str, Any]
) -> dict[str, Any]:
    selection = "id title extraFields" + (" reportId" if table == "reportedFinding" else "")
    mutation = f"update_{table}"
    result = await gw._post(
        f"""mutation CPTCUpdateExtraFields($id: bigint!, $fields: jsonb!) {{
          {mutation}(
            where: {{id: {{_eq: $id}}}},
            _append: {{extraFields: $fields}}
          ) {{ affected_rows returning {{ {selection} }} }}
        }}""",
        {"id": row_id, "fields": fields},
    )
    updated = (result.get("data") or {}).get(mutation) or {}
    rows = updated.get("returning") or []
    if not updated.get("affected_rows") or not rows:
        raise gw.GhostwriterNotFoundError(f"No accessible {table} with id {row_id}.")
    return rows[0]


@server.tool(annotations=READ_ONLY)
async def list_ghostwriter_report_findings(reportId: int) -> list[dict[str, Any]]:
    """List report-specific finding copies with CVSS, order, and custom fields.

    Unlike the shared findings library, these are the findings actually attached
    to the report. Resolve severityId names with list_ghostwriter_lookups.
    """
    try:
        result = await gw._post(
            """query CPTCReportFindings($reportId: bigint!) {
              reportedFinding(
                where: {reportId: {_eq: $reportId}},
                order_by: {id: asc}
              ) {
                id title reportId severityId position cvssScore cvssVector extraFields
              }
            }""",
            {"reportId": _positive_id(reportId, "reportId")},
        )
        return (result.get("data") or {}).get("reportedFinding") or []
    except Exception as exc:
        raise ToolError(str(exc)) from exc


@server.tool(annotations=READ_ONLY)
async def list_ghostwriter_finding_field_specs() -> list[dict[str, Any]]:
    """List custom finding field specifications shown in the web editor.

    Includes each field's internal name, label, type, and display position.
    This helps identify duplicate editor fields before running a maintenance
    migration; the manager GraphQL role cannot change field specifications.
    """
    try:
        result = await gw._post(
            """query CPTCFindingFieldSpecs {
              extraFieldSpec(
                where: {targetModel: {_eq: "reporting.Finding"}},
                order_by: [{position: asc}, {id: asc}]
              ) {
                id internalName displayName type description position targetModel
              }
            }""",
            {},
        )
        return (result.get("data") or {}).get("extraFieldSpec") or []
    except Exception as exc:
        raise ToolError(str(exc)) from exc


@server.tool(annotations=READ_ONLY)
async def get_ghostwriter_report_finding_by_id(
    reportedFindingId: int,
) -> dict[str, Any]:
    """Read one attached finding's report-specific severity and narrative.

    The ID must be a reportedFindingId from a report-finding list, not a shared
    findings-library ID. Includes the current custom MITRE fields.
    """
    try:
        row_id = _positive_id(reportedFindingId, "reportedFindingId")
        result = await gw._post(
            """query CPTCReportFinding($id: bigint!) {
              reportedFinding(where: {id: {_eq: $id}}, limit: 1) {
                id title reportId severityId position description impact mitigation
                replication_steps affectedEntities cvssScore cvssVector extraFields
              }
            }""",
            {"id": row_id},
        )
        rows = (result.get("data") or {}).get("reportedFinding") or []
        if not rows:
            raise gw.GhostwriterNotFoundError(
                f"No accessible reportedFinding with id {row_id}."
            )
        return rows[0]
    except Exception as exc:
        raise ToolError(str(exc)) from exc


@server.tool(annotations=READ_ONLY)
async def list_ghostwriter_report_evidence(reportId: int) -> list[dict[str, Any]]:
    """List evidence metadata attached to a report, including image IDs.

    Rich-text finding narratives refer to these IDs with data-evidence-id.
    Use get_ghostwriter_evidence_image to read an image's content.
    """
    try:
        result = await gw._post(
            """query CPTCReportEvidence($reportId: bigint!) {
              evidence(where: {reportId: {_eq: $reportId}}, order_by: {id: asc}) {
                id reportId friendlyName document caption description uploadDate
              }
            }""",
            {"reportId": _positive_id(reportId, "reportId")},
        )
        return (result.get("data") or {}).get("evidence") or []
    except Exception as exc:
        raise ToolError(str(exc)) from exc


def _image_type(data: bytes) -> str | None:
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        return "image/webp"
    return None


@server.tool(annotations=READ_ONLY)
async def get_ghostwriter_evidence_image(
    reportId: int, evidenceId: int,
) -> dict[str, Any]:
    """Read one report-owned evidence image as base64 with its MIME type.

    The MCP media volume is mounted read-only. Only image files beneath this
    report's evidence directory are accessible, up to 8 MiB each.
    """
    try:
        report_id = _positive_id(reportId, "reportId")
        evidence_id = _positive_id(evidenceId, "evidenceId")
        result = await gw._post(
            """query CPTCEvidenceImage($reportId: bigint!, $evidenceId: bigint!) {
              evidence(where: {
                id: {_eq: $evidenceId}, reportId: {_eq: $reportId}
              }, limit: 1) {
                id reportId friendlyName document caption description
              }
            }""",
            {"reportId": report_id, "evidenceId": evidence_id},
        )
        rows = (result.get("data") or {}).get("evidence") or []
        if not rows:
            raise gw.GhostwriterNotFoundError(
                f"No accessible evidence {evidence_id} in report {report_id}."
            )
        row = rows[0]
        document = row["document"]
        if not isinstance(document, str) or not document or "\\" in document:
            raise gw.GhostwriterValidationError("Invalid evidence document path")
        media_root = Path(os.environ.get(
            "GHOSTWRITER_MEDIA_ROOT", "/run/ghostwriter-media"
        )).resolve()
        report_dir = (media_root / "evidence" / str(report_id)).resolve()
        image_path = (media_root / document).resolve()
        if (not report_dir.is_relative_to(media_root)
                or not image_path.is_relative_to(report_dir)
                or not image_path.is_file()):
            raise gw.GhostwriterValidationError("Evidence image is outside this report")
        if image_path.stat().st_size > 8 * 1024 * 1024:
            raise gw.GhostwriterValidationError("Evidence image exceeds 8 MiB")
        data = image_path.read_bytes()
        mime_type = _image_type(data)
        if mime_type is None:
            raise gw.GhostwriterValidationError("Evidence is not a supported image")
        return {
            "id": row["id"], "reportId": row["reportId"],
            "friendlyName": row["friendlyName"], "caption": row["caption"],
            "description": row["description"], "mimeType": mime_type,
            "imageBase64": base64.b64encode(data).decode("ascii"),
        }
    except Exception as exc:
        raise ToolError(str(exc)) from exc


@server.tool(annotations=READ_ONLY)
async def view_ghostwriter_evidence_image(
    reportId: int, evidenceId: int,
) -> Image:
    """Display one report-owned evidence image as native MCP image content.

    Use list_ghostwriter_report_evidence for its ID and metadata. The same
    report scoping, image validation, and size limit as the base64 reader apply.
    """
    payload = await get_ghostwriter_evidence_image(reportId, evidenceId)
    return Image(
        data=base64.b64decode(payload["imageBase64"]),
        format=payload["mimeType"].removeprefix("image/"),
    )


@server.tool(annotations=READ_ONLY)
async def get_ghostwriter_report_extra_fields(reportId: int) -> dict[str, Any]:
    """Read all custom sections on a report, including CPTC executive_summary,
    business_impact, scope, and other deployment-defined extraFields keys.
    """
    try:
        return await _read_extra_fields("report", _positive_id(reportId, "reportId"))
    except Exception as exc:
        raise ToolError(str(exc)) from exc


@server.tool(annotations=UPDATE)
async def update_ghostwriter_report_extra_fields(
    reportId: int, extraFields: dict[str, Any]
) -> dict[str, Any]:
    """Update selected custom report sections atomically, preserving other keys.

    Supply deployment-defined keys such as executive_summary or business_impact.
    Supplied key values replace their previous values; an empty string clears a
    text field. Rich text accepts HTML and follows Ghostwriter's Jinja escaping
    rules. This is a shallow top-level merge, not a recursive nested merge.
    """
    try:
        return await _update_extra_fields(
            "report", _positive_id(reportId, "reportId"), _fields(extraFields)
        )
    except Exception as exc:
        raise ToolError(str(exc)) from exc


@server.tool(annotations=READ_ONLY)
async def get_ghostwriter_report_finding_extra_fields(
    reportedFindingId: int,
) -> dict[str, Any]:
    """Read custom fields on a report's finding copy, including CPTC
    impact_rating, likelihood_rating, mitre_attack, and mitre_mitigation.
    reportedFindingId is the report-copy ID, not the findings-library ID.
    """
    try:
        return await _read_extra_fields(
            "reportedFinding", _positive_id(reportedFindingId, "reportedFindingId")
        )
    except Exception as exc:
        raise ToolError(str(exc)) from exc


@server.tool(annotations=UPDATE)
async def update_ghostwriter_report_finding_extra_fields(
    reportedFindingId: int, extraFields: dict[str, Any]
) -> dict[str, Any]:
    """Update selected custom fields on one report finding, preserving other
    keys and the shared library entry. Use deployment-defined keys such as
    impact_rating, likelihood_rating, mitre_attack, and mitre_mitigation.
    Supplied values replace that key; an empty string clears a text field.
    This is a shallow top-level merge, not a recursive nested merge.
    """
    try:
        return await _update_extra_fields(
            "reportedFinding",
            _positive_id(reportedFindingId, "reportedFindingId"),
            _fields(extraFields),
        )
    except Exception as exc:
        raise ToolError(str(exc)) from exc


if __name__ == "__main__":
    server.run(transport="stdio")

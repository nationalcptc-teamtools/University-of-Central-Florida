"""Custom-field contract checks against mocked HTTP responses, no live writes."""

import base64
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import ghostwriter_api as gw
import httpx2
import server
from mcp.server.mcpserver.exceptions import ToolError


class ExtensionTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.requests = []
        self.environment = mock.patch.dict(
            os.environ,
            {
                "GHOSTWRITER_GRAPHQL_URL": "https://ghostwriter.test/v1/graphql",
                "GHOSTWRITER_API_TOKEN": "unit-test-token",
            },
            clear=True,
        )
        self.environment.start()
        gw.set_transport(None)

    async def asyncTearDown(self):
        await gw.close_client()
        gw.set_transport(None)
        self.environment.stop()

    def response(self, payload):
        def handler(request):
            self.requests.append(json.loads(request.content))
            return httpx2.Response(200, json=payload)

        gw.set_transport(httpx2.MockTransport(handler))

    async def test_report_create_uses_only_manager_writable_columns(self):
        row = {"id": 7, "title": "New report", "projectId": 3, "last_update": "2026-10-19"}
        self.response({"data": {"insert_report_one": row}})
        result = await server.create_ghostwriter_report(" New report ", 3)
        self.assertEqual(result, {
            **row,
            "_workflow_note": "Save this 'id' as reportId for attach_finding_to_report",
        })
        self.assertEqual(self.requests[0]["variables"], {
            "object": {"title": "New report", "projectId": 3},
        })
        self.assertEqual(len(self.requests), 1)
        self.assertIn("$object: report_insert_input!", self.requests[0]["query"])

    async def test_report_create_schema_omits_unwritable_last_update(self):
        tools = {tool.name: tool for tool in await server.server.list_tools()}
        tool = tools["create_ghostwriter_report"]
        self.assertEqual(set(tool.input_schema["properties"]), {"title", "projectId"})
        self.assertEqual(set(tool.input_schema["required"]), {"title", "projectId"})
        self.assertFalse(tool.annotations.read_only_hint)

    async def test_report_create_empty_result_is_a_tool_error(self):
        self.response({"data": {"insert_report_one": None}})
        with self.assertRaisesRegex(ToolError, "Failed to create report"):
            await server.create_ghostwriter_report("New report", 3)

    async def test_report_create_graphql_error_is_a_tool_error(self):
        self.response({"errors": [{"message": "permission denied"}]})
        with self.assertRaisesRegex(ToolError, "permission denied"):
            await server.create_ghostwriter_report("New report", 3)

    async def test_report_create_validates_before_sending(self):
        self.response({})
        for title, project_id in (("", 3), (" ", 3), ("New report", 0), ("New report", True)):
            with self.subTest(title=title, project_id=project_id), self.assertRaises(ToolError):
                await server.create_ghostwriter_report(title, project_id)
        self.assertEqual(self.requests, [])

    async def test_report_read_returns_custom_sections(self):
        row = {"id": 7, "title": "Test", "extraFields": {"executive_summary": "<p>A</p>"}}
        self.response({"data": {"report": [row]}})
        self.assertEqual(await server.get_ghostwriter_report_extra_fields(7), row)
        self.assertEqual(self.requests[0]["variables"], {"id": 7})
        self.assertIn("$id: bigint!", self.requests[0]["query"])

    async def test_report_finding_read_returns_its_report_id(self):
        row = {"id": 8, "title": "Test", "reportId": 7, "extraFields": {"mitre_attack": "T1059"}}
        self.response({"data": {"reportedFinding": [row]}})
        self.assertEqual(await server.get_ghostwriter_report_finding_extra_fields(8), row)
        self.assertIn("reportId", self.requests[0]["query"])

    async def test_list_report_findings_returns_report_copy_severities(self):
        row = {
            "id": 8, "title": "Critical finding", "reportId": 7,
            "severityId": 5, "position": 1, "cvssScore": 9.3,
            "cvssVector": "CVSS:4.0/AV:N", "extraFields": {"mitre_attack": ""},
        }
        self.response({"data": {"reportedFinding": [row]}})
        self.assertEqual(await server.list_ghostwriter_report_findings(7), [row])
        self.assertEqual(self.requests[0]["variables"], {"reportId": 7})
        query = self.requests[0]["query"]
        self.assertIn("reportedFinding(", query)
        self.assertIn("reportId: {_eq: $reportId}", query)
        self.assertIn("severityId", query)
        self.assertIn("position cvssScore cvssVector", query)
        self.assertIn("extraFields", query)

    async def test_list_finding_field_specs_is_scoped_and_read_only(self):
        row = {
            "id": 15, "internalName": "mitre_attack",
            "displayName": "MITRE ATT&CK Technique", "type": "single_line_text",
            "description": "ATT&CK technique", "position": 3,
            "targetModel": "reporting.Finding",
        }
        self.response({"data": {"extraFieldSpec": [row]}})
        self.assertEqual(await server.list_ghostwriter_finding_field_specs(), [row])
        self.assertEqual(len(self.requests), 1)
        query = self.requests[0]["query"]
        self.assertIn('targetModel: {_eq: "reporting.Finding"}', query)
        self.assertIn("order_by: [{position: asc}, {id: asc}]", query)
        self.assertIn("internalName displayName type", query)
        self.assertEqual(self.requests[0]["variables"], {})

    async def test_report_finding_detail_returns_report_specific_narrative(self):
        row = {
            "id": 8, "title": "Critical finding", "reportId": 7,
            "severityId": 5, "description": "<p>Observed</p>",
            "replication_steps": "<p>Reproduced</p>",
            "affectedEntities": "host.example",
            "extraFields": {"mitre_attack": ""},
        }
        self.response({"data": {"reportedFinding": [row]}})
        self.assertEqual(await server.get_ghostwriter_report_finding_by_id(8), row)
        self.assertEqual(self.requests[0]["variables"], {"id": 8})
        query = self.requests[0]["query"]
        self.assertIn("description", query)
        self.assertIn("replication_steps", query)
        self.assertIn("affectedEntities", query)
        self.assertIn("severityId position", query)
        self.assertNotIn("finding(where:", query)

    async def test_report_finding_detail_missing_and_empty_list(self):
        self.response({"data": {"reportedFinding": []}})
        self.assertEqual(await server.list_ghostwriter_report_findings(7), [])
        with self.assertRaisesRegex(ToolError, "No accessible reportedFinding"):
            await server.get_ghostwriter_report_finding_by_id(99999)

    async def test_report_evidence_list_is_scoped_to_report(self):
        row = {"id": 9, "reportId": 7, "friendlyName": "Proof",
               "document": "evidence/7/proof.png", "caption": "Proof",
               "description": "", "uploadDate": "2026-10-10"}
        self.response({"data": {"evidence": [row]}})
        self.assertEqual(await server.list_ghostwriter_report_evidence(7), [row])
        self.assertEqual(self.requests[0]["variables"], {"reportId": 7})
        self.assertIn("reportId: {_eq: $reportId}", self.requests[0]["query"])

    async def test_evidence_image_reads_only_report_owned_image(self):
        with tempfile.TemporaryDirectory() as media_root:
            image = Path(media_root) / "evidence" / "7" / "proof.png"
            image.parent.mkdir(parents=True)
            content = b"\x89PNG\r\n\x1a\nimage-data"
            image.write_bytes(content)
            os.environ["GHOSTWRITER_MEDIA_ROOT"] = media_root
            row = {"id": 9, "reportId": 7, "friendlyName": "Proof",
                   "document": "evidence/7/proof.png", "caption": "Proof",
                   "description": ""}
            self.response({"data": {"evidence": [row]}})
            result = await server.get_ghostwriter_evidence_image(7, 9)
            self.assertEqual(result["mimeType"], "image/png")
            self.assertEqual(base64.b64decode(result["imageBase64"]), content)
            native = await server.view_ghostwriter_evidence_image(7, 9)
            block = native.to_image_content()
            self.assertEqual(block.mime_type, "image/png")
            self.assertEqual(base64.b64decode(block.data), content)
            self.assertEqual(self.requests[0]["variables"],
                             {"reportId": 7, "evidenceId": 9})
            row["document"] = "evidence/8/proof.png"
            self.response({"data": {"evidence": [row]}})
            with self.assertRaisesRegex(ToolError, "outside this report"):
                await server.get_ghostwriter_evidence_image(7, 9)

    async def test_report_update_is_one_atomic_append(self):
        fields = {"executive_summary": "<p>Changed</p>"}
        row = {"id": 7, "extraFields": {**fields, "business_impact": "Retained"}}
        self.response({"data": {"update_report": {"affected_rows": 1, "returning": [row]}}})
        result = await server.update_ghostwriter_report_extra_fields(7, fields)
        self.assertEqual(result["extraFields"]["business_impact"], "Retained")
        self.assertEqual(len(self.requests), 1)
        self.assertEqual(self.requests[0]["variables"], {"id": 7, "fields": fields})
        self.assertIn("_append: {extraFields: $fields}", self.requests[0]["query"])
        self.assertNotIn("_set", self.requests[0]["query"])
        self.assertIn("$fields: jsonb!", self.requests[0]["query"])

    async def test_finding_update_only_targets_the_report_copy(self):
        fields = {"mitre_attack": "T1059", "impact_rating": "High"}
        row = {"id": 8, "extraFields": fields}
        self.response({"data": {"update_reportedFinding": {"affected_rows": 1, "returning": [row]}}})
        self.assertEqual(await server.update_ghostwriter_report_finding_extra_fields(8, fields), row)
        query = self.requests[0]["query"]
        self.assertIn("update_reportedFinding(", query)
        self.assertNotIn("update_finding(", query)
        self.assertIn("_append: {extraFields: $fields}", query)

    async def test_empty_string_can_clear_one_section(self):
        row = {"id": 7, "extraFields": {"executive_summary": ""}}
        self.response({"data": {"update_report": {"affected_rows": 1, "returning": [row]}}})
        await server.update_ghostwriter_report_extra_fields(7, {"executive_summary": ""})
        self.assertEqual(self.requests[0]["variables"]["fields"], {"executive_summary": ""})

    async def test_nonexistent_reads_are_tool_errors(self):
        for table, function in (
            ("report", server.get_ghostwriter_report_extra_fields),
            ("reportedFinding", server.get_ghostwriter_report_finding_extra_fields),
            ("reportedFinding", server.get_ghostwriter_report_finding_by_id),
        ):
            with self.subTest(table=table):
                self.response({"data": {table: []}})
                with self.assertRaisesRegex(ToolError, "No accessible"):
                    await function(99999)

    async def test_nonexistent_updates_are_tool_errors(self):
        for table, function in (
            ("report", server.update_ghostwriter_report_extra_fields),
            ("reportedFinding", server.update_ghostwriter_report_finding_extra_fields),
        ):
            with self.subTest(table=table):
                self.response({"data": {f"update_{table}": {"affected_rows": 0, "returning": []}}})
                with self.assertRaisesRegex(ToolError, "No accessible"):
                    await function(99999, {"example": "value"})

    async def test_graphql_errors_are_tool_errors(self):
        self.response({"errors": [{"message": "permission denied"}]})
        with self.assertRaisesRegex(ToolError, "permission denied"):
            await server.update_ghostwriter_report_extra_fields(7, {"executive_summary": "A"})

    async def test_invalid_ids_never_send_requests(self):
        self.response({})
        for value in (True, 0, -1, "1", 1.5):
            with self.subTest(value=value), self.assertRaises(ToolError):
                await server.get_ghostwriter_report_extra_fields(value)
            with self.subTest(value=value), self.assertRaises(ToolError):
                await server.list_ghostwriter_report_findings(value)
            with self.subTest(value=value), self.assertRaises(ToolError):
                await server.get_ghostwriter_report_finding_by_id(value)
            with self.subTest(value=value), self.assertRaises(ToolError):
                await server.list_ghostwriter_report_evidence(value)
            with self.subTest(value=value), self.assertRaises(ToolError):
                await server.get_ghostwriter_evidence_image(7, value)
            with self.subTest(value=value), self.assertRaises(ToolError):
                await server.view_ghostwriter_evidence_image(7, value)
        self.assertEqual(self.requests, [])

    async def test_invalid_patch_never_sends_requests(self):
        self.response({})
        for fields in ({}, [], {"": "bad"}, {" ": "bad"}, {1: "bad"}):
            with self.subTest(fields=fields), self.assertRaises(ToolError):
                await server.update_ghostwriter_report_extra_fields(7, fields)
        self.assertEqual(self.requests, [])

    async def test_tools_are_registered_with_honest_annotations(self):
        tools = {tool.name: tool for tool in await server.server.list_tools()}
        for name in (
            "get_ghostwriter_report_extra_fields",
            "get_ghostwriter_report_finding_extra_fields",
            "list_ghostwriter_report_findings",
            "list_ghostwriter_finding_field_specs",
            "get_ghostwriter_report_finding_by_id",
            "list_ghostwriter_report_evidence",
            "get_ghostwriter_evidence_image",
            "view_ghostwriter_evidence_image",
            "update_ghostwriter_report_extra_fields",
            "update_ghostwriter_report_finding_extra_fields",
        ):
            self.assertIn(name, tools)
            read_only = name.startswith(("get_", "list_", "view_"))
            self.assertEqual(tools[name].annotations.read_only_hint, read_only)
            self.assertEqual(tools[name].annotations.destructive_hint, not read_only)


if __name__ == "__main__":
    unittest.main()

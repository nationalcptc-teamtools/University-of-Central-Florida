#!/usr/bin/env bash
# Generate the self-signed TLS material nginx needs, if it isn't there yet.
#
# Keys are never committed - ssl/ is gitignored - so each clone makes its own.
# Matches what gwcli generates: O=Ghostwriter / CN=nginx, 1 year, 2048-bit DH.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p ssl

if [[ -f ssl/ghostwriter.crt && -f ssl/ghostwriter.key && -f ssl/dhparam.pem ]]; then
    exit 0
fi

echo "==> generating self-signed TLS certificate for nginx"
if [[ ! -f ssl/ghostwriter.crt || ! -f ssl/ghostwriter.key ]]; then
    openssl req -x509 -nodes -newkey rsa:2048 -days 365 \
        -subj "/O=Ghostwriter/CN=nginx" \
        -keyout ssl/ghostwriter.key -out ssl/ghostwriter.crt 2>/dev/null
    echo "    ssl/ghostwriter.crt + .key"
fi

if [[ ! -f ssl/dhparam.pem ]]; then
    # 2048-bit DH params take a minute or so. One time only.
    echo "    ssl/dhparam.pem (this takes a minute)"
    openssl dhparam -out ssl/dhparam.pem 2048 2>/dev/null
fi

chmod 600 ssl/ghostwriter.key
echo "    done - browsers will warn about the self-signed cert, that's expected"
